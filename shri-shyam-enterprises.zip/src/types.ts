export type Category = 
  | 'Phone Covers' 
  | 'Chargers' 
  | 'Cables' 
  | 'Earbuds' 
  | 'Tempered Glass' 
  | 'Power Banks' 
  | 'Holders';

export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  category: Category;
  rating: number;
  reviewsCount: number;
  image: string;
  images: string[];
  description: string;
  features: string[];
  specs: Record<string, string>;
  isFeatured?: boolean;
  isNew?: boolean;
  isBestSeller?: boolean;
  stockStatus: 'in_stock' | 'low_stock' | 'out_of_stock';
}

export interface SelectedOptions {
  brand?: string;
  model?: string;
  color?: string;
  material?: string;
  finish?: string;
  glassType?: string;
}

export interface CartItem {
  id: string; // Unique ID composed of product.id + selected options hash
  product: Product;
  quantity: number;
  selectedOptions?: SelectedOptions;
}

export interface CheckoutDetails {
  name: string;
  phone: string;
  email?: string;
  address: string;
  city: string;
  state: string;
  pinCode: string;
  notes?: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  rating: number;
  comment: string;
  date: string;
}

export interface BrandModel {
  brand: string;
  models: string[];
}
