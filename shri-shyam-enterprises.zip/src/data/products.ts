import { Product, Testimonial, BrandModel } from '../types';

export const BRANDS_AND_MODELS: BrandModel[] = [
  {
    brand: 'Apple',
    models: [
      'iPhone 16 Pro Max',
      'iPhone 16 Pro',
      'iPhone 16 Plus',
      'iPhone 16',
      'iPhone 15 Pro Max',
      'iPhone 15 Pro',
      'iPhone 15 Plus',
      'iPhone 15',
      'iPhone 14 Pro Max',
      'iPhone 14 Pro',
      'iPhone 13 Pro',
      'iPhone 13',
      'iPhone 12'
    ]
  },
  {
    brand: 'Samsung',
    models: [
      'Galaxy S24 Ultra',
      'Galaxy S24+',
      'Galaxy S24',
      'Galaxy S23 Ultra',
      'Galaxy S23',
      'Galaxy S23 FE',
      'Galaxy A55 5G',
      'Galaxy A35 5G',
      'Galaxy Z Fold5',
      'Galaxy Z Flip5'
    ]
  },
  {
    brand: 'OnePlus',
    models: ['OnePlus 12', 'OnePlus 12R', 'OnePlus 11 5G', 'OnePlus 11R', 'OnePlus Nord CE4', 'OnePlus Nord 3']
  },
  {
    brand: 'Nothing',
    models: ['Phone (2)', 'Phone (2a)', 'Phone (1)']
  },
  {
    brand: 'Xiaomi',
    models: ['Xiaomi 14 Ultra', 'Xiaomi 14', 'Redmi Note 13 Pro+ 5G', 'Redmi Note 13 Pro', 'Redmi 13C 5G']
  },
  {
    brand: 'Realme',
    models: ['Realme GT 6', 'Realme GT 6T', 'Realme 12 Pro+ 5G', 'Realme 12+ 5G', 'Realme Narzo 70 Pro']
  },
  {
    brand: 'Vivo',
    models: ['Vivo X100 Pro', 'Vivo V30 Pro', 'Vivo V30e', 'Vivo T3 5G', 'Vivo Y200e 5G']
  },
  {
    brand: 'Oppo',
    models: ['Oppo Find X7 Ultra', 'Oppo Reno 11 Pro 5G', 'Oppo Reno 11 5G', 'Oppo F25 Pro 5G', 'Oppo A79 5G']
  },
  {
    brand: 'Motorola',
    models: ['Edge 50 Ultra', 'Edge 50 Pro', 'Edge 50 Fusion', 'G84 5G', 'G54 5G']
  },
  {
    brand: 'Google Pixel',
    models: ['Pixel 9 Pro XL', 'Pixel 9 Pro', 'Pixel 9', 'Pixel 8a', 'Pixel 8 Pro', 'Pixel 8', 'Pixel 7a']
  },
  {
    brand: 'iQOO',
    models: ['iQOO 12', 'iQOO Neo9 Pro', 'iQOO Z9 5G', 'iQOO Z9x 5G', 'iQOO 11']
  },
  {
    brand: 'POCO',
    models: ['POCO X6 Pro 5G', 'POCO X6 5G', 'POCO F6 5G', 'POCO M6 Pro 5G']
  }
];

export const GLASS_TYPES = [
  'Privacy Tempered Glass',
  '9H Clear Premium Glass',
  'Matte Anti-Glare Tempered Glass',
  'UV Liquid Curved Glass',
  'Super-D Armour Shatterproof Glass'
];

export const PHONE_COVER_COLORS = [
  { name: 'Midnight Black', hex: '#0f172a' },
  { name: 'Titanium Gray', hex: '#64748b' },
  { name: 'Pacific Blue', hex: '#1d4ed8' },
  { name: 'Emerald Green', hex: '#065f46' },
  { name: 'Crimson Red', hex: '#991b1b' },
  { name: 'Sunset Orange', hex: '#ea580c' },
  { name: 'Sunset Gold', hex: '#d97706' },
  { name: 'Crystal Clear', hex: '#e2e8f0', isClear: true }
];

export const PHONE_COVER_MATERIALS = [
  'Premium Liquid Silicone',
  'Ultra-Protective Heavy Armor',
  'Sleek Vegan Leather',
  'Cryo-Cooling Gel-Infused Hybrid',
  'Ultra-Light Aerospace Carbon Fiber',
  'Clear Hybrid Polycarbonate'
];

export const PHONE_COVER_FINISHES = [
  'Soft-Touch Matte Finish',
  'Anti-Yellowing Glossy Clear',
  'Textured Hex-Grip Carbon Fiber',
  'Satin Metallic-Rim Border',
  'Premium Leather Grain Texture'
];

export const PRODUCTS: Product[] = [
  {
    id: 'phone-cover',
    name: 'Custom Premium Phone Cover',
    price: 499,
    originalPrice: 999,
    category: 'Phone Covers',
    rating: 4.8,
    reviewsCount: 1240,
    image: 'https://images.unsplash.com/photo-1603302576837-37561b2e2302?w=600&auto=format&fit=crop&q=80',
    images: [
      'https://images.unsplash.com/photo-1603302576837-37561b2e2302?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1581090700227-136177be801f?w=600&auto=format&fit=crop&q=80'
    ],
    description: 'Protect your valuable smartphone with our range of Premium Customizable Phone Covers. Tailored perfectly to fit over a massive variety of Apple, Samsung, OnePlus, Nothing, Vivo, Xiaomi, Oppo, Realme, and Motorola smartphones. Made from premium non-toxic eco-friendly materials with specialized impact protection and raised lip guards to shield your screen and camera lenses.',
    features: [
      'Engineered with 10ft Military-Grade Drop Protection',
      'Tactile click responsive buttons and perfect port cutouts',
      'Anti-dust coating with fingerprint-resistant specialized coating',
      'Fully compatible with MagSafe and Qi-wireless charging protocols',
      'Enhanced camera ring lip guard (+1.5mm) and screen bezel lip guard (+1.2mm)'
    ],
    specs: {
      'Available Brands': 'Apple, Samsung, OnePlus, Nothing, Vivo, Xiaomi, Oppo, Realme, Motorola',
      'Materials Available': 'Liquid Silicone, Heavy Armor, Vegan Leather, Carbon Fiber, Hybrid PC',
      'Finish Styles': 'Soft Matte, Clear Gloss, Carbon Fiber Textured, Metallic Rim',
      'Drop Protection': 'Up to 3 meters / 10 feet military-grade cert',
      'Thickness': '1.2mm to 2.4mm (depending on material choice)',
      'Weight': 'Approx 28g to 42g'
    },
    isFeatured: true,
    isBestSeller: true,
    stockStatus: 'in_stock'
  },
  {
    id: 'gan-charger-65w',
    name: 'HyperCharge 65W GaN Multi-Port Charger',
    price: 1499,
    originalPrice: 2499,
    category: 'Chargers',
    rating: 4.9,
    reviewsCount: 820,
    image: 'https://images.unsplash.com/photo-1622445262465-2481c4574875?w=600&auto=format&fit=crop&q=80',
    images: [
      'https://images.unsplash.com/photo-1622445262465-2481c4574875?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=600&auto=format&fit=crop&q=80'
    ],
    description: 'Experience ultra-fast, ultra-cool charging with our pocket-sized Gallium Nitride (GaN) multi-port fast wall charger. Delivering up to 65W of raw charging speed, this charger can easily power up your earbuds, accessories, and multiple accessories simultaneously. Features intelligent power distribution across its dual USB-C ports and single USB-A port.',
    features: [
      'Powered by advanced Gallium Nitride (GaN III) Technology for 40% smaller footprint',
      'Dynamic power allocation technology senses connected accessories for maximum efficiency',
      'Up to 3x faster charging compared to standard inbox 5W chargers',
      'Built-in Multi-Protect system guarding against over-current, overheating, and short circuits',
      'Universal compatibility with USB PD 3.0, Quick Charge 4.0, and PPS standards'
    ],
    specs: {
      'Maximum Output': '65W Max',
      'Ports': '2 x USB Type-C, 1 x USB Type-A',
      'Technology': 'GaN III Semiconductor Technology',
      'Input Voltage': '100-240V ~ 50/60Hz (Worldwide Travel Compatible)',
      'Dimensions': '52mm x 40mm x 30mm',
      'Weight': '95g'
    },
    isFeatured: true,
    isNew: true,
    stockStatus: 'in_stock'
  },
  {
    id: 'braided-cable-100w',
    name: 'VeloSync 100W PD Braided USB-C to C Cable',
    price: 399,
    originalPrice: 799,
    category: 'Cables',
    rating: 4.7,
    reviewsCount: 610,
    image: 'https://images.unsplash.com/photo-1589156280159-27698a70f29e?w=600&auto=format&fit=crop&q=80',
    images: [
      'https://images.unsplash.com/photo-1589156280159-27698a70f29e?w=600&auto=format&fit=crop&q=80'
    ],
    description: 'An exceptionally durable, high-speed charging cable designed to withstand daily wear and tear. Built with double-braided nylon exterior and reinforced Kevlar cores, this cable supports high-capacity Power Delivery up to 100W for extremely fast charging cycles. Perfect companion for your 65W GaN adapter and accessories.',
    features: [
      'Supports 100W Power Delivery (20V/5A) for super-fast charging',
      'Tested to survive over 30,000+ bends with reinforced strain relief collars',
      'Gold-plated contacts and anodized aluminum housings for pristine signal transmission',
      'Ultra-dense high-tensile nylon weave protects against fraying and pet chewing',
      'Includes premium leather cable wrap for convenient organization'
    ],
    specs: {
      'Connectors': 'USB-C to USB-C',
      'Cable Length': '2.0 meters / 6.6 feet',
      'Max Power Output': '100W (20V / 5A)',
      'Data Transfer Rate': '480 Mbps (USB 2.0)',
      'Material': 'Anodized Aluminum + Braided Ballistic Nylon'
    },
    isFeatured: false,
    stockStatus: 'in_stock'
  },
  {
    id: 'wireless-earbuds-neopulse',
    name: 'NeoPulse ANC Wireless Earbuds',
    price: 2499,
    originalPrice: 4999,
    category: 'Earbuds',
    rating: 4.8,
    reviewsCount: 350,
    image: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=600&auto=format&fit=crop&q=80',
    images: [
      'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=600&auto=format&fit=crop&q=80'
    ],
    description: 'Immerse yourself in rich, high-fidelity audio with the NeoPulse Wireless Earbuds. Packed with active noise cancellation (up to 32dB) and custom-tuned 12mm composite drivers, these earbuds offer booming bass and crystal clear trebles. Features ultra-low latency game mode and sweatproof engineering.',
    features: [
      'Hybrid Active Noise Cancellation (ANC) with Ambient Transparency Mode',
      'Total 36 Hours of playtime (8 hrs on earbuds + 28 hrs with sleek case)',
      'Quad-Mics with AI Environmental Noise Cancellation for ultra-clear phone calls',
      'IPX5 Water & Sweat Resistance rating perfect for gym sessions and running',
      'Intuitive smart touch control pads on stems with instant Siri/Google Assistant support'
    ],
    specs: {
      'Bluetooth Version': 'Bluetooth v5.3 (Instant Pair)',
      'Driver Size': '12mm Dynamic Composite Drivers',
      'Battery Capacity': '40mAh (Earbuds), 400mAh (Charging Case)',
      'Charging Time': '1.5 Hours via USB-C, Supports wireless charging',
      'Audio Codecs': 'AAC, SBC'
    },
    isFeatured: true,
    isBestSeller: true,
    stockStatus: 'in_stock'
  },
  {
    id: 'tempered-glass-apex',
    name: 'Tempered Glass',
    price: 399,
    originalPrice: 799,
    category: 'Tempered Glass',
    rating: 4.6,
    reviewsCount: 1840,
    image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=600&auto=format&fit=crop&q=80',
    images: [
      'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=600&auto=format&fit=crop&q=80'
    ],
    description: 'Shield your precious screen from high impact drops, deep scratches, and grease smudges. The Apex Armour Tempered Glass features specialized 9H diamond hardness with seamless edge-to-edge curved borders that fit under any phone case without bubbling. Complete with self-install alignment frames.',
    features: [
      '9H Diamond-grade hardness protects against keys, knives, and hard impacts',
      'Ultra-thin 0.33mm profile retains 99.9% screen touch sensitivity and feedback',
      'Hydrophobic and Oleophobic coatings repel grease, fingerprints, and sweat smudges',
      'Case-friendly design with 2.5D curved polished edges for a smooth tactile drag',
      'Self-expelling air adhesive layer ensures completely bubble-free setup'
    ],
    specs: {
      'Hardness': '9H Mohs Scale',
      'Thickness': '0.33mm Ultra-thin',
      'Clarity': '99.9% Super-D clear',
      'Edge Type': '2.5D Polished Rounded Borders',
      'Coating': 'Double Oleophobic Hydrophobic coating'
    },
    isFeatured: false,
    stockStatus: 'in_stock'
  },
  {
    id: 'powerbank-powermax-20k',
    name: 'PowerMax 20000mAh 22.5W Fast Power Bank',
    price: 1799,
    originalPrice: 2999,
    category: 'Power Banks',
    rating: 4.8,
    reviewsCount: 430,
    image: 'https://images.unsplash.com/photo-1609592424109-dd032338b30c?w=600&auto=format&fit=crop&q=80',
    images: [
      'https://images.unsplash.com/photo-1609592424109-dd032338b30c?w=600&auto=format&fit=crop&q=80'
    ],
    description: 'Unleash portable power with the ultra-slim 20,000mAh backup power bank. Featuring 22.5W super fast output, it is engineered to charge your phone up to 50% in just 30 minutes. Includes a premium smart LED digital screen that tells you the exact remaining power percentage, and three output ports.',
    features: [
      'Massive 20000mAh capacity provides up to 4-5 full phone charges',
      'Equipped with 22.5W Power Delivery and Quick Charge 3.0 outputs',
      'Smart Digital LED display shows precise battery levels (1% incremental)',
      'Triple-port charging options (2 x USB-A QC output, 1 x USB-C PD Input/Output)',
      'Intelligent IC chipset prevents over-charging, over-discharging, and voltage spikes'
    ],
    specs: {
      'Capacity': '20,000mAh / 74Wh',
      'Max Output Power': '22.5W',
      'Inputs': 'USB-C (18W PD), Micro-USB (18W)',
      'Outputs': '1 x USB-C (20W/22.5W Max), 2 x USB-A (22.5W Max)',
      'Body Material': 'Fire-retardant PC + ABS Textured Anti-slip casing',
      'Weight': '340g'
    },
    isFeatured: true,
    stockStatus: 'low_stock'
  },
  {
    id: 'magsafe-car-holder',
    name: 'AeroMount Magnetic Air Vent Car Holder',
    price: 899,
    originalPrice: 1499,
    category: 'Holders',
    rating: 4.7,
    reviewsCount: 220,
    image: 'https://images.unsplash.com/photo-1600080972464-8e5f35f63d08?w=600&auto=format&fit=crop&q=80',
    images: [
      'https://images.unsplash.com/photo-1600080972464-8e5f35f63d08?w=600&auto=format&fit=crop&q=80'
    ],
    description: 'Keep your device steady and visible while cruising. The AeroMount Car Holder incorporates 16 powerful N52 neodymium magnets arranged in a perfect MagSafe ring pattern, providing ultra-strong grip even on bumpy roads. Mounts securely to standard air vents with a sturdy steel clamp.',
    features: [
      '16 x N52 Neodymium military-grade magnets with up to 1.8kg static pull force',
      '360-Degree rotation ball-joint lets you view your device in portrait or landscape',
      'Upgrade-designed heavy-duty spiral hook vent clamp prevents sagging and slipping',
      'Soft protective silicone contact pad protects your premium case/phone from scratches',
      'Fully compatible with MagSafe-enabled phones and MagSafe phone cases'
    ],
    specs: {
      'Mounting Type': 'Air Vent Clip Clamp',
      'Magnet Strength': '16 Heavy-duty N52 Magnets',
      'Compatibility': 'MagSafe iPhones (12/13/14/15) and any device with metal plate',
      'Joint Rotation': '360° Omnidirectional',
      'Material': 'Aviation-grade Aluminum Alloy + Non-slip Silicone'
    },
    isFeatured: false,
    stockStatus: 'in_stock'
  },
  {
    id: 'desktop-metal-holder',
    name: 'OmniStand Adjustable Desktop Metal Holder',
    price: 599,
    originalPrice: 999,
    category: 'Holders',
    rating: 4.8,
    reviewsCount: 310,
    image: 'https://images.unsplash.com/photo-1586105251261-72a756497a11?w=600&auto=format&fit=crop&q=80',
    images: [
      'https://images.unsplash.com/photo-1586105251261-72a756497a11?w=600&auto=format&fit=crop&q=80'
    ],
    description: 'Boost your workspace utility and posture. The OmniStand is crafted from premium sandblasted aluminum alloy and is fully foldable for easy carry. Features dual-axis height and angle adjustments to provide the perfect eye level for watching tutorials, attending video calls, or monitoring notifications.',
    features: [
      'Dual-Axis 270° angle adjustment and 4.3-inch telescoping height slider',
      'Foldable flat design easily fits into pocket, laptop sleeve, or accessory bag',
      'Anti-slip protective rubber cushions on hooks and under the base prevent sliding',
      'Convenient cable passage slot lets you charge your accessory while docked',
      'Weighted carbon-steel reinforced base resists tipping over under heavy load'
    ],
    specs: {
      'Material': 'Sandblasted Aluminum Alloy + Carbon Steel Core',
      'Weight Support': 'Holds up to 750g devices',
      'Folded Size': '110mm x 66mm x 26mm',
      'Max Height Extension': '14.5 cm / 5.7 inches',
      'Weight': '180g'
    },
    isFeatured: false,
    stockStatus: 'in_stock'
  },
  {
    id: 'cable-protector-helix',
    name: 'Helix Coil Silicone Cable Protector (4-Pack)',
    price: 99,
    originalPrice: 199,
    category: 'Cables',
    rating: 4.5,
    reviewsCount: 950,
    image: 'https://images.unsplash.com/photo-1616440347437-b1c73416efc2?w=600&auto=format&fit=crop&q=80',
    images: [
      'https://images.unsplash.com/photo-1616440347437-b1c73416efc2?w=600&auto=format&fit=crop&q=80'
    ],
    description: 'Stop spending money on replacement charging cables. Our Helix Coil protectors wrap snugly around the joint of charging cables, preventing the outer jacket from tearing or breaking at the point of stress. Highly flexible and available in premium aesthetic pastel tones.',
    features: [
      'Made from premium flexible, odor-free, non-deforming silicone',
      'Increases cable longevity by over 500% by restricting sharp bending stress',
      'Extremely easy installation - spiral wrap wraps around the cable in under 10 seconds',
      'Universal compatibility - fits round, flat, and braided cables of standard diameter',
      'Pack includes 4 stylish modern dual-tone pastel colors'
    ],
    specs: {
      'Pack Contents': '4 Cable Protectors',
      'Material': 'High-tensile Grade-A Elastic Silicone',
      'Length': '3.2 cm per protector',
      'Inner Diameter': '8mm (elastic fit down to 3.5mm)',
      'Weight': '2g per unit'
    },
    isFeatured: false,
    stockStatus: 'in_stock'
  },
  {
    id: 'magsafe-powerbank-10k',
    name: 'VoltCore 10000mAh MagSafe Power Bank',
    price: 1999,
    originalPrice: 3499,
    category: 'Power Banks',
    rating: 4.9,
    reviewsCount: 180,
    image: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=600&auto=format&fit=crop&q=80',
    images: [
      'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=600&auto=format&fit=crop&q=80'
    ],
    description: 'Get charging convenience without the cords. VoltCore aligns magnetically with compatible iPhones (12/13/14/15/16 series) and wireless charging cases, staying secure on the go. Boasting 15W wireless output plus 20W wired Power Delivery, this pocket-sized brick is absolute tech-luxury.',
    features: [
      'Super strong N52 magnetic grip aligns perfectly for wire-free charging',
      '15W Fast Wireless Output & 20W PD Wired output via USB-C port',
      'Pass-through charging enables you to charge your phone and powerbank simultaneously',
      'Remarkably slim 13.5mm thickness, leaves camera lenses fully uncovered',
      'Elegantly coated in a soft matte anti-fingerprint rubberized grip'
    ],
    specs: {
      'Capacity': '10,000mAh / 37Wh',
      'Wireless Output': '15W / 10W / 7.5W / 5W',
      'USB-C Input/Output': 'PD 20W Max (5V/3A, 9V/2.22A)',
      'Thickness': '13.5 mm',
      'Weight': '165g'
    },
    isFeatured: true,
    isNew: true,
    stockStatus: 'in_stock'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 't1',
    name: 'Rahul Sharma',
    role: 'Verified Buyer',
    rating: 5,
    comment: 'The Custom Premium Silicone Case fits my Galaxy S24 Ultra perfectly. The texture is soft, but it gives amazing grip. The delivery was fast, and placing the order via WhatsApp was super easy and fast. Highly recommended!',
    date: 'June 12, 2026'
  },
  {
    id: 't2',
    name: 'Pooja Mehta',
    role: 'Tech Enthusiast',
    rating: 5,
    comment: 'Bought the 65W GaN Charger and the Braided Cable. It charges my earbuds and accessories with incredible speed. Solid build quality, authentic accessories. No more heating issues like standard local chargers.',
    date: 'May 28, 2026'
  },
  {
    id: 't3',
    name: 'Vikram Singh',
    role: 'Daily Commuter',
    rating: 5,
    comment: 'I am so impressed with the AeroMount MagSafe Car Holder. It holds my phone strongly even during bad bumpy road patches here. Excellent customer support from Shri Shyam Enterprises over WhatsApp. A trustworthy seller!',
    date: 'June 20, 2026'
  }
];

export const TIMELINE_EVENTS = [
  {
    year: '2020',
    title: 'The Humble Beginning',
    description: 'Shri Shyam Enterprises opened its doors as a passionate retail shop specializing in premium protective cases and accessories.'
  },
  {
    year: '2022',
    title: 'Catering to All Brands',
    description: 'Expanded catalog to include chargers, adapters, and custom tempered glass for over 200+ mobile models, becoming the local go-to spot.'
  },
  {
    year: '2024',
    title: 'Digital & Wholesale Footprint',
    description: 'Launched our online catalog and streamlined ordering through direct customer WhatsApp support, ensuring nationwide shipping and trust.'
  },
  {
    year: '2026',
    title: 'Modern Accessory Hub',
    description: 'Providing a premium, handpicked accessories collection centering on the latest GaN charger models, magnetic mounts, and carbon fiber cases.'
  }
];

export const STATS = [
  { value: '15,000+', label: 'Happy Customers' },
  { value: '500+', label: 'Accessory Varieties' },
  { value: '99.9%', label: 'Delivery Success Rate' },
  { value: '4.8★', label: 'Average Customer Rating' }
];
