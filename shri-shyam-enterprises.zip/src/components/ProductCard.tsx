import { MouseEvent } from 'react';
import { Eye, ShoppingCart, Star, Settings } from 'lucide-react';
import { Product } from '../types';
import SafeImage from './SafeImage';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onNavigateToProduct: (productId: string) => void;
}

export default function ProductCard({
  product,
  onAddToCart,
  onQuickView,
  onNavigateToProduct,
}: ProductCardProps) {
  const isPhoneCover = product.id === 'phone-cover';
  const discountPercent = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  const handleProductClick = () => {
    onNavigateToProduct(product.id);
  };

  const handleAddToCartClick = (e: MouseEvent) => {
    e.stopPropagation();
    if (isPhoneCover) {
      // Phone covers require option selections, trigger quick view/customize flow instead
      onQuickView(product);
    } else {
      onAddToCart(product);
    }
  };

  return (
    <div
      onClick={handleProductClick}
      className="group relative flex flex-col justify-between bg-zinc-900/80 rounded-2xl border border-zinc-800 hover:border-blue-900/60 shadow-xs hover:-translate-y-1.5 transition-all duration-300 cursor-pointer overflow-hidden h-full"
      id={`product-card-${product.id}`}
    >
      {/* Product Image & Badges */}
      <div className="relative aspect-square w-full overflow-hidden bg-zinc-950 flex items-center justify-center border-b border-zinc-900">
        <SafeImage
          productId={product.id}
          fallbackUrl={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />

        {/* Highlight Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10">
          {product.isBestSeller && (
            <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-1 rounded-lg bg-amber-500 text-white shadow-xs">
              Bestseller
            </span>
          )}
          {product.isNew && (
            <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-1 rounded-lg bg-blue-600 text-white shadow-xs">
              New Arrival
            </span>
          )}
          {discountPercent > 0 && (
            <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-1 rounded-lg bg-red-500 text-white shadow-xs">
              {discountPercent}% OFF
            </span>
          )}
        </div>

        {/* Quick actions overlay (desktop only) */}
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-2 z-10">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onQuickView(product);
            }}
            className="p-3 rounded-xl bg-zinc-850 hover:bg-blue-600 text-white shadow-md transform translate-y-4 group-hover:translate-y-0 transition-all duration-300 cursor-pointer"
            title="Quick View"
            id={`product-quickview-btn-${product.id}`}
          >
            <Eye className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Product Details Content */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
        <div className="space-y-1.5">
          {/* Category & Ratings */}
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest font-mono">
              {product.category}
            </span>
            <div className="flex items-center gap-1 text-amber-400">
              <Star className="w-3 h-3 fill-amber-400" />
              <span className="text-xs font-bold text-slate-300">{product.rating}</span>
            </div>
          </div>

          {/* Name */}
          <h3 className="font-display font-semibold text-slate-100 group-hover:text-blue-400 transition-colors text-sm sm:text-base leading-tight tracking-tight line-clamp-2">
            {product.name}
          </h3>

          {/* Reviews count and availability status */}
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-slate-400">({product.reviewsCount} reviews)</span>
            {product.stockStatus === 'low_stock' ? (
              <span className="text-amber-400 font-medium">Only few left!</span>
            ) : product.stockStatus === 'out_of_stock' ? (
              <span className="text-red-400 font-medium">Out of stock</span>
            ) : (
              <span className="text-green-400 font-medium">In Stock</span>
            )}
          </div>
        </div>

        {/* Pricing & Add to Cart footer */}
        <div className="mt-4 pt-3 border-t border-zinc-800/60 flex items-center justify-between gap-2">
          <div className="flex items-baseline gap-1.5 flex-wrap">
            <span className="text-base sm:text-lg font-black text-slate-50">₹{product.price}</span>
            {product.originalPrice && (
              <span className="text-xs text-slate-500 line-through">₹{product.originalPrice}</span>
            )}
          </div>

          <button
            onClick={handleAddToCartClick}
            disabled={product.stockStatus === 'out_of_stock'}
            className={`px-3 py-2 sm:px-4 rounded-xl flex items-center gap-1.5 text-xs font-semibold cursor-pointer transition-all duration-300 ${
              product.stockStatus === 'out_of_stock'
                ? 'bg-zinc-800 text-slate-500 cursor-not-allowed'
                : isPhoneCover
                ? 'bg-blue-950/40 hover:bg-blue-600 text-blue-400 hover:text-white border border-blue-900/60'
                : 'bg-zinc-800 hover:bg-blue-600 text-white shadow-sm hover:shadow'
            }`}
            id={`product-action-btn-${product.id}`}
          >
            {isPhoneCover ? (
              <>
                <Settings className="w-3.5 h-3.5" />
                <span className="hidden xs:inline">Customize</span>
              </>
            ) : (
              <>
                <ShoppingCart className="w-3.5 h-3.5" />
                <span className="hidden xs:inline">Add</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
