import { useState, useEffect, MouseEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Smartphone, Zap, Headphones, Sparkles, Move } from 'lucide-react';

type AccessoryType = 'case' | 'charger' | 'earbuds';

export default function Hero3D() {
  const [activeType, setActiveType] = useState<AccessoryType>('case');
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  // Handle subtle mouse parallax movement over the showcase container
  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5; // range -0.5 to 0.5
    const y = (e.clientY - rect.top) / rect.height - 0.5; // range -0.5 to 0.5
    setMousePos({ x, y });
  };

  const handleMouseLeave = () => {
    setMousePos({ x: 0, y: 0 });
  };

  // Auto-rotate the active product every 8 seconds unless hovered/changed
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveType((prev) => {
        if (prev === 'case') return 'charger';
        if (prev === 'charger') return 'earbuds';
        return 'case';
      });
    }, 8000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div 
      className="relative w-full max-w-lg aspect-square mx-auto flex items-center justify-center p-6 cursor-grab active:cursor-grabbing select-none"
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      id="hero-3d-container"
    >
      {/* Background Ambience / Glowing Gradients */}
      <div className="absolute inset-0 bg-radial from-blue-500/10 via-transparent to-transparent blur-3xl rounded-full scale-110 pointer-events-none" />
      <div className="absolute inset-4 bg-radial from-cyan-400/5 via-transparent to-transparent blur-2xl rounded-full scale-95 pointer-events-none" />

      {/* Decorative Interactive Floating Grid */}
      <div className="absolute inset-0 border border-slate-200/40 rounded-3xl [mask-image:radial-gradient(ellipse_at_center,black_60%,transparent_100%)] pointer-events-none">
        <div className="absolute inset-0 grid grid-cols-8 grid-rows-8 opacity-25">
          {Array.from({ length: 64 }).map((_, i) => (
            <div key={i} className="border-[0.5px] border-slate-300" />
          ))}
        </div>
      </div>

      {/* Parallax Layer for 3D Accessory Model */}
      <div 
        className="relative w-full h-full flex items-center justify-center transition-transform duration-500 ease-out"
        style={{
          transform: `perspective(1000px) rotateY(${mousePos.x * 25}deg) rotateX(${-mousePos.y * 25}deg)`,
        }}
      >
        <AnimatePresence mode="wait">
          {activeType === 'case' && (
            <motion.div
              key="case-3d"
              initial={{ opacity: 0, scale: 0.8, rotate: -15 }}
              animate={{ opacity: 1, scale: 1, rotate: 5 }}
              exit={{ opacity: 0, scale: 0.8, rotate: 15 }}
              transition={{ type: 'spring', damping: 15, stiffness: 100 }}
              className="absolute w-[80%] h-[80%] flex items-center justify-center"
            >
              {/* Premium Phone Cover Layering */}
              <div className="relative w-48 h-96 rounded-[40px] border-4 border-slate-900 bg-slate-950 shadow-2xl p-3 flex flex-col justify-between overflow-hidden">
                {/* Simulated Phone Screen Details */}
                <div className="absolute inset-1 rounded-[34px] bg-slate-900 flex flex-col justify-between p-4 overflow-hidden">
                  {/* Dynamic Island Notch */}
                  <div className="w-16 h-4 bg-black rounded-full mx-auto" />
                  
                  {/* Mock UI lock screen */}
                  <div className="text-center mt-4">
                    <div className="text-xs text-slate-400 font-mono tracking-widest">SHRI SHYAM</div>
                    <div className="text-3xl font-display font-light text-slate-100 mt-1">14:42</div>
                    <div className="text-[10px] text-blue-400 font-medium tracking-wide mt-1">SUPER CHARGING</div>
                  </div>

                  {/* Charging Wave Vector */}
                  <div className="w-full flex justify-center py-2">
                    <svg className="w-20 h-10 text-blue-500/40" viewBox="0 0 100 40">
                      <path d="M0,20 Q15,5 30,20 T60,20 T90,20" fill="none" stroke="currentColor" strokeWidth="2" />
                      <path d="M10,25 Q25,10 40,25 T70,25 T100,25" fill="none" stroke="currentColor" strokeWidth="1" opacity="0.5" />
                    </svg>
                  </div>
                </div>

                {/* Overlaid Floating Premium Transparent Case */}
                <motion.div 
                  className="absolute -inset-2 rounded-[46px] border border-white/60 shadow-[0_0_20px_rgba(255,255,255,0.4)] backdrop-blur-[2px] bg-white/10 p-3 flex flex-col justify-between pointer-events-none"
                  animate={{ 
                    y: [0, -8, 0],
                    rotateY: [0, 8, 0]
                  }}
                  transition={{ 
                    duration: 5, 
                    repeat: Infinity, 
                    ease: "easeInOut" 
                  }}
                >
                  {/* Case Corner Bumpers */}
                  <div className="absolute -top-1 -left-1 w-4 h-4 rounded-tl-[12px] border-t-2 border-l-2 border-blue-400/80" />
                  <div className="absolute -top-1 -right-1 w-4 h-4 rounded-tr-[12px] border-t-2 border-r-2 border-blue-400/80" />
                  <div className="absolute -bottom-1 -left-1 w-4 h-4 rounded-bl-[12px] border-b-2 border-l-2 border-blue-400/80" />
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-br-[12px] border-b-2 border-r-2 border-blue-400/80" />

                  {/* MagSafe Ring illustration */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center opacity-85">
                    {/* Ring */}
                    <div className="w-24 h-24 rounded-full border-2 border-dashed border-white/80 flex items-center justify-center shadow-[0_0_15px_rgba(37,99,235,0.2)]">
                      <div className="w-20 h-20 rounded-full border border-white/40 flex items-center justify-center">
                        <Smartphone className="w-6 h-6 text-white/90" />
                      </div>
                    </div>
                    {/* Alignment Line */}
                    <div className="w-1.5 h-8 bg-white/80 rounded-full mt-2" />
                  </div>

                  {/* Highlight Specular Reflections */}
                  <div className="absolute top-0 left-4 w-12 h-[300px] bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-12 rotate-12 blur-[1px] opacity-60" />
                </motion.div>
              </div>

              {/* Floor Shadow */}
              <div className="absolute -bottom-6 w-40 h-4 bg-slate-900/20 blur-md rounded-full" />
            </motion.div>
          )}

          {activeType === 'charger' && (
            <motion.div
              key="charger-3d"
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: -20 }}
              transition={{ type: 'spring', damping: 15, stiffness: 100 }}
              className="absolute w-full h-full flex flex-col items-center justify-center"
            >
              {/* Premium Charger Graphic */}
              <div className="relative">
                <motion.div 
                  className="relative w-44 h-44 rounded-3xl bg-slate-900 shadow-2xl border border-slate-700/50 p-6 flex flex-col justify-between"
                  animate={{ y: [0, -12, 0] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                >
                  {/* Connector Prongs Indicator */}
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 flex gap-4 pointer-events-none">
                    <div className="w-2.5 h-4 bg-slate-700 rounded-t" />
                    <div className="w-2.5 h-4 bg-slate-700 rounded-t" />
                  </div>

                  {/* Futuristic charging status screen / branding */}
                  <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                    <div className="text-xs font-mono font-medium text-slate-400">GAN III</div>
                    <span className="flex h-2 w-2 relative">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
                    </span>
                  </div>

                  {/* Giant Glowing Power logo */}
                  <div className="my-2 flex items-center justify-center">
                    <div className="relative p-3 rounded-full bg-slate-800/80 border border-slate-700 shadow-inner">
                      <Zap className="w-10 h-10 text-cyan-400 fill-cyan-400/20" />
                      <div className="absolute -inset-1 border border-cyan-400/30 rounded-full animate-ping" />
                    </div>
                  </div>

                  {/* Smart Port Panels */}
                  <div className="flex justify-center gap-3">
                    <div className="w-7 h-2.5 rounded bg-blue-500/20 border border-blue-500/50 flex items-center justify-center"><div className="w-4 h-[1px] bg-blue-400" /></div>
                    <div className="w-7 h-2.5 rounded bg-blue-500/20 border border-blue-500/50 flex items-center justify-center"><div className="w-4 h-[1px] bg-blue-400" /></div>
                    <div className="w-7 h-2.5 rounded bg-amber-500/20 border border-amber-500/50 flex items-center justify-center"><div className="w-4 h-1 bg-amber-400 rounded-sm" /></div>
                  </div>
                </motion.div>

                {/* Floating energy particles */}
                <motion.div 
                  className="absolute -top-6 -left-6 text-blue-400"
                  animate={{ y: [0, -15, 0], opacity: [0.3, 1, 0.3] }}
                  transition={{ duration: 3, repeat: Infinity, delay: 0.5 }}
                >
                  <Sparkles className="w-5 h-5" />
                </motion.div>
                <motion.div 
                  className="absolute -bottom-4 -right-4 text-cyan-400"
                  animate={{ y: [0, -20, 0], opacity: [0.2, 0.8, 0.2] }}
                  transition={{ duration: 4, repeat: Infinity, delay: 1 }}
                >
                  <Sparkles className="w-4 h-4" />
                </motion.div>
              </div>

              {/* Floor Shadow */}
              <div className="absolute bottom-12 w-32 h-3 bg-slate-900/35 blur-md rounded-full" />
            </motion.div>
          )}

          {activeType === 'earbuds' && (
            <motion.div
              key="earbuds-3d"
              initial={{ opacity: 0, scale: 0.8, rotate: 15 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              exit={{ opacity: 0, scale: 0.8, rotate: -15 }}
              transition={{ type: 'spring', damping: 15, stiffness: 100 }}
              className="absolute w-full h-full flex flex-col items-center justify-center"
            >
              <div className="relative">
                {/* Sleek Matte Black Earbud Case */}
                <motion.div 
                  className="w-40 h-36 rounded-[35px] bg-slate-900 shadow-2xl border border-slate-800 flex flex-col justify-between p-4"
                  animate={{ y: [0, -6, 0] }}
                  transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
                >
                  <div className="w-12 h-1 bg-slate-800 rounded-full mx-auto" />
                  <div className="flex justify-center my-4">
                    <div className="w-3 h-3 rounded-full bg-blue-500 shadow-[0_0_8px_#2563eb]" />
                  </div>
                  <div className="text-center font-mono text-[9px] tracking-widest text-slate-500">NEOPULSE AUDIO</div>
                </motion.div>

                {/* Left Earbud Floating Out */}
                <motion.div 
                  className="absolute -top-12 -left-8 p-3 rounded-full bg-slate-800 border border-slate-700 shadow-xl"
                  animate={{ 
                    y: [0, -18, 0], 
                    rotate: [0, -8, 0] 
                  }}
                  transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut" }}
                >
                  <Headphones className="w-8 h-8 text-blue-400" />
                  <div className="absolute top-1 right-1 w-2 h-2 rounded-full bg-cyan-400" />
                </motion.div>

                {/* Right Earbud Floating Out */}
                <motion.div 
                  className="absolute -top-16 -right-6 p-3 rounded-full bg-slate-800 border border-slate-700 shadow-xl"
                  animate={{ 
                    y: [0, -22, 0], 
                    rotate: [0, 12, 0] 
                  }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay: 0.3 }}
                >
                  <Headphones className="w-8 h-8 text-blue-400 scale-x-[-1]" />
                  <div className="absolute top-1 left-1 w-2 h-2 rounded-full bg-cyan-400" />
                </motion.div>
              </div>

              {/* Floor Shadow */}
              <div className="absolute bottom-10 w-32 h-3.5 bg-slate-900/30 blur-md rounded-full" />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Manual Product Switcher Dots / Controls */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-3 py-2 px-4 rounded-full bg-white/70 border border-slate-200/50 shadow-sm backdrop-blur-md z-10">
        <button
          onClick={() => setActiveType('case')}
          className={`p-2 rounded-full transition-all duration-300 ${activeType === 'case' ? 'bg-blue-600 text-white shadow' : 'text-slate-600 hover:bg-slate-100'}`}
          title="Case Showcase"
          id="btn-showcase-case"
        >
          <Smartphone className="w-4 h-4" />
        </button>
        <button
          onClick={() => setActiveType('charger')}
          className={`p-2 rounded-full transition-all duration-300 ${activeType === 'charger' ? 'bg-blue-600 text-white shadow' : 'text-slate-600 hover:bg-slate-100'}`}
          title="Charger Showcase"
          id="btn-showcase-charger"
        >
          <Zap className="w-4 h-4" />
        </button>
        <button
          onClick={() => setActiveType('earbuds')}
          className={`p-2 rounded-full transition-all duration-300 ${activeType === 'earbuds' ? 'bg-blue-600 text-white shadow' : 'text-slate-600 hover:bg-slate-100'}`}
          title="Earbuds Showcase"
          id="btn-showcase-earbuds"
        >
          <Headphones className="w-4 h-4" />
        </button>
      </div>

      {/* Float Hint */}
      <div className="absolute top-4 right-4 flex items-center gap-1.5 text-[10px] font-mono text-slate-400 bg-slate-100/60 border border-slate-200/40 rounded-full px-2.5 py-1 backdrop-blur-xs">
        <Move className="w-3 h-3 animate-pulse" />
        <span>DRAG TO ROTATE</span>
      </div>
    </div>
  );
}
