import { Smartphone, Mail, Phone, MapPin, ArrowRight, MessageSquare, Instagram, Facebook, Twitter, ShieldCheck } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: string) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  const handleLinkClick = (pageId: string) => {
    onNavigate(pageId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-black text-slate-400 pt-16 pb-8 border-t border-zinc-900" id="global-footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
        
        {/* Column 1: Brand & Desc (Col span 4) */}
        <div className="lg:col-span-4 space-y-5">
          <button
            onClick={() => handleLinkClick('home')}
            className="flex items-center gap-2 text-left cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white font-display font-bold text-xl shadow-[0_4px_12px_rgba(37,99,235,0.3)]">
              S
            </div>
            <div>
              <span className="font-display font-bold text-white text-base sm:text-lg tracking-tight block">
                Shri Shyam
              </span>
              <span className="text-[10px] text-blue-400 font-mono tracking-widest block font-bold -mt-1">
                ACCESSORIES
              </span>
            </div>
          </button>
          <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
            Premium, high-end e-commerce store specializing in top-tier protective covers, hyper-speed charging units, dual-braided PD cables, and exact-fit tempered screen protection. We prioritize device safety above all.
          </p>
          <div className="flex gap-3 pt-1">
            <a href="https://instagram.com" target="_blank" rel="noreferrer" className="p-2 rounded-xl bg-zinc-900 border border-zinc-800 hover:bg-blue-600 hover:text-white transition-colors" title="Instagram">
              <Instagram className="w-4 h-4" />
            </a>
            <a href="https://facebook.com" target="_blank" rel="noreferrer" className="p-2 rounded-xl bg-zinc-900 border border-zinc-800 hover:bg-blue-600 hover:text-white transition-colors" title="Facebook">
              <Facebook className="w-4 h-4" />
            </a>
            <a href="https://twitter.com" target="_blank" rel="noreferrer" className="p-2 rounded-xl bg-zinc-900 border border-zinc-800 hover:bg-blue-600 hover:text-white transition-colors" title="Twitter/X">
              <Twitter className="w-4 h-4" />
            </a>
          </div>
        </div>

        {/* Column 2: Quick Links (Col span 2) */}
        <div className="lg:col-span-2 space-y-4">
          <h4 className="text-xs font-black text-white font-mono uppercase tracking-wider">Quick Links</h4>
          <ul className="space-y-2 text-xs">
            {['home', 'shop', 'custom-order', 'about', 'contact'].map((page) => (
              <li key={page}>
                <button
                  onClick={() => handleLinkClick(page)}
                  className="hover:text-blue-400 transition-colors capitalize text-left cursor-pointer flex items-center gap-1 group"
                >
                  <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-all -translate-x-1 group-hover:translate-x-0" />
                  <span>
                    {page === 'about' ? 'About Us' : page === 'custom-order' ? 'Custom Order' : page}
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* Column 3: Contact Info (Col span 3) */}
        <div className="lg:col-span-3 space-y-4 text-xs">
          <h4 className="text-xs font-black text-white font-mono uppercase tracking-wider">Contact Store</h4>
          <ul className="space-y-3.5">
            <li className="flex gap-2.5 items-start">
              <MapPin className="w-4 h-4 text-blue-500 flex-shrink-0" />
              <span>Shri Shyam Enterprises, Bajaj Road, Near Shriram Coaching, Sikar, Rajasthan - 332001, India</span>
            </li>
            <li className="flex gap-2.5 items-center">
              <Phone className="w-4 h-4 text-blue-500 flex-shrink-0" />
              <span className="font-mono">+91 89497 01510</span>
            </li>
            <li className="flex gap-2.5 items-center">
              <Mail className="w-4 h-4 text-blue-500 flex-shrink-0" />
              <span className="font-mono">support@shrishyam.com</span>
            </li>
          </ul>
        </div>

        {/* Column 4: Delivery Badges (Col span 3) */}
        <div className="lg:col-span-3 space-y-4">
          <h4 className="text-xs font-black text-white font-mono uppercase tracking-wider">Store Logistics</h4>
          <p className="text-[11px] text-slate-500 leading-relaxed">
            All orders dispatch within 24 hours of placement. Fully tracked and secure shipment using elite local delivery services.
          </p>
          <div className="flex items-center gap-2 p-3.5 rounded-xl bg-zinc-900 border border-zinc-800 text-[10px] text-slate-350">
            <ShieldCheck className="w-4.5 h-4.5 text-blue-400 flex-shrink-0" />
            <div>
              <span className="font-bold text-white block">Safe & Certified Seller</span>
              <span className="text-[9px] text-slate-500 block">Checked fits & verified delivery.</span>
            </div>
          </div>
        </div>

      </div>

      {/* Copyright Disclaimer strip */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 pt-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-[10px] text-slate-500 font-mono uppercase tracking-wider">
        <div>
          &copy; {currentYear} SHRI SHYAM ENTERPRISES. ALL RIGHTS RESERVED.
        </div>
        <div className="flex gap-4">
          <span>SECURE CHECKOUT VIA WHATSAPP</span>
          <span>&bull;</span>
          <span>MOBILE ACCESSORIES SPECIALISTS</span>
        </div>
      </div>
    </footer>
  );
}
