import { useState, useEffect } from 'react';
import { Menu, X, ShoppingBag, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  cartItemsCount: number;
  onCartOpen: () => void;
}

export default function Navbar({ currentPage, onNavigate, cartItemsCount, onCartOpen }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Track scrolling to apply shadow/backdrop effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 15);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'shop', label: 'Shop' },
    { id: 'custom-order', label: 'Custom Order' },
    { id: 'about', label: 'About Us' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleLinkClick = (pageId: string) => {
    onNavigate(pageId);
    setIsMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 w-full z-40 transition-all duration-300 ${
          isScrolled
            ? 'glass-effect py-3 shadow-md border-b border-zinc-800/50'
            : 'bg-transparent py-5'
        }`}
        id="main-navbar"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          
          {/* Logo / Brand Name */}
          <button
            onClick={() => handleLinkClick('home')}
            className="flex items-center gap-2 group text-left cursor-pointer"
            id="nav-logo-button"
          >
            <div className="relative w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white font-display font-bold text-lg shadow-[0_4px_12px_rgba(37,99,235,0.3)] group-hover:scale-105 transition-transform">
              S
              <div className="absolute inset-0 border border-white/20 rounded-xl" />
            </div>
            <div>
              <span className="font-display font-bold text-white text-base sm:text-lg tracking-tight block">
                Shri Shyam
              </span>
              <span className="text-[10px] text-blue-400 font-mono tracking-widest block font-bold -mt-1">
                ACCESSORIES
              </span>
            </div>
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleLinkClick(link.id)}
                className={`relative py-1 text-sm font-medium tracking-wide cursor-pointer transition-colors ${
                  currentPage === link.id
                    ? 'text-blue-400 font-semibold'
                    : 'text-slate-300 hover:text-white'
                }`}
                id={`nav-desktop-link-${link.id}`}
              >
                {link.label}
                {currentPage === link.id && (
                  <motion.div
                    layoutId="activeNavIndicator"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-500 rounded-full"
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
              </button>
            ))}
          </nav>

          {/* Utility Buttons */}
          <div className="flex items-center gap-3 sm:gap-4">
            {/* Cart Icon Button */}
            <button
              onClick={onCartOpen}
              className="relative p-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-slate-200 transition-all cursor-pointer flex items-center justify-center border border-zinc-800/50"
              title="Open Cart"
              id="navbar-cart-button"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartItemsCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-blue-600 text-[10px] font-bold text-white shadow-md animate-bounce-subtle">
                  {cartItemsCount}
                </span>
              )}
            </button>

            {/* CTA Custom Order Button - Desktop Only */}
            <button
              onClick={() => handleLinkClick('custom-order')}
              className="hidden sm:flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-md cursor-pointer hover:shadow-lg transition-all border border-blue-500/30"
              id="navbar-custom-order-cta"
            >
              <span>Custom Order</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            {/* Mobile Hamburger Trigger */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2.5 rounded-xl bg-zinc-900 text-slate-200 hover:bg-zinc-800 transition-colors cursor-pointer border border-zinc-800/50"
              aria-label="Toggle Menu"
              id="navbar-mobile-menu-trigger"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

        </div>
      </header>

      {/* Mobile Nav Sidebar Slide-out */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            {/* Dark Overlay Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.4 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 bg-black z-41 md:hidden"
              id="mobile-nav-overlay"
            />

            {/* Sidebar drawer */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 h-full w-[280px] sm:w-[320px] bg-zinc-950 border-l border-zinc-900 z-42 shadow-2xl p-6 flex flex-col justify-between md:hidden"
              id="mobile-nav-sidebar"
            >
              <div className="flex flex-col gap-8">
                {/* Header inside drawer */}
                <div className="flex items-center justify-between border-b border-zinc-900 pb-4">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-display font-bold text-sm">
                      S
                    </div>
                    <span className="font-display font-bold text-white text-sm tracking-tight">
                      Shri Shyam
                    </span>
                  </div>
                  <button
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="p-1.5 rounded-lg bg-zinc-900 text-slate-400 border border-zinc-800/50"
                    id="mobile-nav-close-btn"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {/* Nav Links List */}
                <nav className="flex flex-col gap-4">
                  {navLinks.map((link) => (
                    <button
                      key={link.id}
                      onClick={() => handleLinkClick(link.id)}
                      className={`flex items-center justify-between p-3 rounded-xl text-left font-medium transition-all ${
                        currentPage === link.id
                          ? 'bg-blue-950/40 text-blue-400 font-semibold border border-blue-900/40'
                          : 'text-slate-300 hover:bg-zinc-900 hover:text-white'
                      }`}
                      id={`nav-mobile-link-${link.id}`}
                    >
                      <span>{link.label}</span>
                      <ArrowRight className={`w-4 h-4 opacity-50 transition-transform ${currentPage === link.id ? 'translate-x-1 opacity-100' : ''}`} />
                    </button>
                  ))}
                </nav>
              </div>

              {/* Quick Info Footer inside mobile drawer */}
              <div className="border-t border-zinc-900 pt-6">
                <div className="text-[10px] font-mono text-zinc-500 tracking-wider mb-2">QUICK ORDERS</div>
                <div className="text-xs text-zinc-400">WhatsApp support response in minutes.</div>
                <button
                  onClick={() => handleLinkClick('shop')}
                  className="w-full mt-4 py-3 rounded-xl bg-zinc-900 text-white text-center text-sm font-semibold hover:bg-blue-600 border border-zinc-800 transition-colors"
                  id="mobile-drawer-shop-cta"
                >
                  Shop Now
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
