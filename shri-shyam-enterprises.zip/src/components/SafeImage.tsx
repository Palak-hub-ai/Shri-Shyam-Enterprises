import { useState, useEffect, ImgHTMLAttributes, CSSProperties } from 'react';

interface SafeImageProps extends ImgHTMLAttributes<HTMLImageElement> {
  productId: string;
  fallbackUrl: string;
  alt?: string;
  className?: string;
  style?: CSSProperties;
  loading?: 'lazy' | 'eager';
}

export default function SafeImage({
  productId,
  fallbackUrl,
  alt,
  className,
  ...props
}: SafeImageProps) {
  // Primary path is the local directory path: /images/{productId}/{productId}.png
  const primaryPath = `/images/${productId}/${productId}.png`;
  const [currentSrc, setCurrentSrc] = useState(primaryPath);
  const [hasFailed, setHasFailed] = useState(false);

  // If the productId or fallbackUrl changes, reset the state
  useEffect(() => {
    setCurrentSrc(`/images/${productId}/${productId}.png`);
    setHasFailed(false);
  }, [productId, fallbackUrl]);

  const handleError = () => {
    if (!hasFailed) {
      // If primary path fails, switch to stock/CDN image as the secondary fallback path
      setHasFailed(true);
      setCurrentSrc(fallbackUrl);
    } else if (currentSrc !== fallbackUrl) {
      // If fallback also fails, use a generic neutral placeholder
      setCurrentSrc('https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=600&auto=format&fit=crop&q=80');
    }
  };

  return (
    <img
      src={currentSrc}
      alt={alt}
      onError={handleError}
      className={className}
      referrerPolicy="no-referrer"
      {...props}
    />
  );
}
