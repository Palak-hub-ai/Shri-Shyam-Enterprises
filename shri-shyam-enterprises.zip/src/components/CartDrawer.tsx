import { ShoppingBag, X, Plus, Minus, Trash2, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CartItem } from '../types';
import SafeImage from './SafeImage';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onNavigateToCheckout: () => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onNavigateToCheckout,
}: CartDrawerProps) {
  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

  const handleCheckoutClick = () => {
    onClose();
    onNavigateToCheckout();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Dark Overlay Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.7 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/90 z-50 cursor-pointer"
            id="cart-drawer-backdrop"
          />

          {/* Cart Sidebar Drawer */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed top-0 right-0 h-full w-full max-w-md bg-zinc-950 z-51 border-l border-zinc-900 flex flex-col justify-between"
            id="cart-drawer-container"
          >
            {/* Header */}
            <div className="p-6 border-b border-zinc-900 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-blue-400" />
                <span className="font-display font-bold text-lg text-white">Your Cart</span>
                <span className="text-xs bg-blue-950/40 text-blue-400 border border-blue-900/30 px-2 py-0.5 rounded-full font-semibold">
                  {cartItems.reduce((acc, item) => acc + item.quantity, 0)} items
                </span>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-slate-400 hover:text-white border border-zinc-850 transition-colors cursor-pointer"
                id="cart-drawer-close-btn"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Cart Items List */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {cartItems.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center">
                  <div className="w-16 h-16 rounded-full bg-zinc-900/60 border border-zinc-850 flex items-center justify-center mb-4">
                    <ShoppingBag className="w-8 h-8 text-slate-600" />
                  </div>
                  <h3 className="font-display font-medium text-white mb-1 text-base">Your cart is empty</h3>
                  <p className="text-xs text-slate-400 max-w-xs mb-6 font-sans">
                    Looks like you haven't added any premium accessories to your cart yet.
                  </p>
                  <button
                    onClick={onClose}
                    className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow transition-colors cursor-pointer"
                    id="cart-drawer-empty-shop-cta"
                  >
                    Start Shopping
                  </button>
                </div>
              ) : (
                cartItems.map((item) => (
                  <motion.div
                    key={item.id}
                    layout
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="flex gap-4 p-3.5 rounded-xl border border-zinc-850 bg-zinc-900/40 hover:bg-zinc-900/80 transition-colors group"
                    id={`cart-item-card-${item.id}`}
                  >
                    {/* Product Image */}
                    <div className="w-16 h-16 rounded-lg overflow-hidden bg-zinc-950 border border-zinc-850 flex-shrink-0">
                      <SafeImage
                        productId={item.product.id}
                        fallbackUrl={item.product.image}
                        alt={item.product.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>

                    {/* Product Details & Actions */}
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-start gap-2">
                          <h4 className="font-medium text-white text-sm leading-snug tracking-tight">
                            {item.product.name}
                          </h4>
                          <button
                            onClick={() => onRemoveItem(item.id)}
                            className="text-slate-500 hover:text-red-400 p-0.5 transition-colors cursor-pointer"
                            title="Remove"
                            id={`cart-item-remove-btn-${item.id}`}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Display custom options for the phone cover or tempered glass */}
                        {item.selectedOptions && (
                          <div className="mt-1 space-y-0.5">
                            {item.selectedOptions.brand && (
                              <div className="text-[10px] text-slate-400">
                                <span className="font-semibold text-slate-300">Device:</span>{' '}
                                {item.selectedOptions.brand} - {item.selectedOptions.model}
                              </div>
                            )}
                            {item.selectedOptions.color && (
                              <div className="text-[10px] text-slate-400 flex items-center gap-1">
                                <span className="font-semibold text-slate-300">Color:</span>{' '}
                                {item.selectedOptions.color}
                              </div>
                            )}
                            {item.selectedOptions.material && (
                              <div className="text-[10px] text-slate-400">
                                <span className="font-semibold text-slate-300">Material:</span>{' '}
                                {item.selectedOptions.material}
                              </div>
                            )}
                            {item.selectedOptions.finish && (
                              <div className="text-[10px] text-slate-400">
                                <span className="font-semibold text-slate-300">Finish:</span>{' '}
                                {item.selectedOptions.finish}
                              </div>
                            )}
                            {item.selectedOptions.glassType && (
                              <div className="text-[10px] text-slate-400">
                                <span className="font-semibold text-slate-300">Glass Type:</span>{' '}
                                {item.selectedOptions.glassType}
                              </div>
                            )}
                          </div>
                        )}
                      </div>

                      {/* Quantity & Price */}
                      <div className="flex items-center justify-between mt-3 pt-2 border-t border-zinc-850">
                        <div className="flex items-center gap-1 bg-zinc-950 border border-zinc-850 rounded-lg p-0.5 shadow-none">
                          <button
                            onClick={() => onUpdateQuantity(item.id, -1)}
                            disabled={item.quantity <= 1}
                            className="p-1 rounded text-slate-400 hover:bg-zinc-900 hover:text-white disabled:opacity-30 disabled:hover:bg-transparent transition-colors cursor-pointer"
                            id={`cart-item-minus-${item.id}`}
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-6 text-center text-xs font-semibold text-slate-200">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQuantity(item.id, 1)}
                            className="p-1 rounded text-slate-400 hover:bg-zinc-900 hover:text-white transition-colors cursor-pointer"
                            id={`cart-item-plus-${item.id}`}
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-bold text-white">
                            ₹{item.product.price * item.quantity}
                          </div>
                          {item.quantity > 1 && (
                            <div className="text-[10px] text-slate-500">
                              ₹{item.product.price} each
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))
              )}
            </div>

            {/* Footer Summary / Checkout action */}
            {cartItems.length > 0 && (
              <div className="p-6 border-t border-zinc-900 space-y-4 shadow-none bg-zinc-950">
                <div className="space-y-2">
                  <div className="flex justify-between text-xs text-slate-400">
                    <span>Items Count</span>
                    <span>{cartItems.reduce((acc, item) => acc + item.quantity, 0)} units</span>
                  </div>
                  <div className="flex justify-between text-xs text-slate-400">
                    <span>Shipping</span>
                    <span className="text-green-400 font-semibold font-mono text-[10px] uppercase">FREE DELIVERY</span>
                  </div>
                  <div className="flex justify-between items-end pt-2 border-t border-zinc-900">
                    <span className="font-display font-bold text-sm text-white">Grand Total</span>
                    <span className="text-xl font-display font-black text-blue-400">₹{subtotal}</span>
                  </div>
                </div>

                <div className="pt-2 space-y-2">
                  <button
                    onClick={handleCheckoutClick}
                    className="w-full py-3.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-none hover:bg-blue-700 transition-all flex items-center justify-center gap-2 cursor-pointer"
                    id="cart-drawer-checkout-btn"
                  >
                    <span>Proceed to Checkout</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <p className="text-[10px] text-center text-slate-500">
                    Orders are instantly processed & confirmed via WhatsApp support chat.
                  </p>
                </div>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
