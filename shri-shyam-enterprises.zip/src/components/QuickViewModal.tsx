import { useState, useEffect } from 'react';
import { X, Star, ShoppingCart, Check, ShieldCheck, Truck, RotateCcw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Product, SelectedOptions } from '../types';
import { BRANDS_AND_MODELS, PHONE_COVER_COLORS, PHONE_COVER_MATERIALS, PHONE_COVER_FINISHES, GLASS_TYPES } from '../data/products';
import SafeImage from './SafeImage';

interface QuickViewModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product, options?: SelectedOptions, quantity?: number) => void;
}

export default function QuickViewModal({
  product,
  isOpen,
  onClose,
  onAddToCart,
}: QuickViewModalProps) {
  if (!product) return null;

  const isPhoneCover = product.id === 'phone-cover';
  const isTemperedGlass = product.id === 'tempered-glass-apex';

  // State for Customizable Cover selections
  const [selectedBrand, setSelectedBrand] = useState(BRANDS_AND_MODELS[0].brand);
  const [selectedModel, setSelectedModel] = useState(BRANDS_AND_MODELS[0].models[0]);
  const [selectedColor, setSelectedColor] = useState(PHONE_COVER_COLORS[0].name);
  const [selectedMaterial, setSelectedMaterial] = useState(PHONE_COVER_MATERIALS[0]);
  const [selectedFinish, setSelectedFinish] = useState(PHONE_COVER_FINISHES[0]);
  const [selectedGlassType, setSelectedGlassType] = useState(GLASS_TYPES[0]);

  // Standard select options
  const [quantity, setQuantity] = useState(1);
  const [activeImageIdx, setActiveImageIdx] = useState(0);

  // Update models dropdown dynamically when brand changes
  useEffect(() => {
    if (isPhoneCover || isTemperedGlass) {
      const match = BRANDS_AND_MODELS.find((b) => b.brand === selectedBrand);
      if (match && match.models.length > 0) {
        setSelectedModel(match.models[0]);
      }
    }
  }, [selectedBrand, isPhoneCover, isTemperedGlass]);

  // Reset states when modal closes or switches product
  useEffect(() => {
    if (isOpen) {
      setQuantity(1);
      setActiveImageIdx(0);
      if (isPhoneCover || isTemperedGlass) {
        setSelectedBrand(BRANDS_AND_MODELS[0].brand);
        setSelectedModel(BRANDS_AND_MODELS[0].models[0]);
        setSelectedColor(PHONE_COVER_COLORS[0].name);
        setSelectedMaterial(PHONE_COVER_MATERIALS[0]);
        setSelectedFinish(PHONE_COVER_FINISHES[0]);
        setSelectedGlassType(GLASS_TYPES[0]);
      }
    }
  }, [isOpen, product, isPhoneCover, isTemperedGlass]);

  const activeBrandModels = BRANDS_AND_MODELS.find((b) => b.brand === selectedBrand)?.models || [];

  const handleAddToCart = () => {
    const configOptions: SelectedOptions | undefined = isPhoneCover
      ? {
          brand: selectedBrand,
          model: selectedModel,
          color: selectedColor,
          material: selectedMaterial,
          finish: selectedFinish,
        }
      : isTemperedGlass
      ? {
          brand: selectedBrand,
          model: selectedModel,
          glassType: selectedGlassType,
        }
      : undefined;

    onAddToCart(product, configOptions, quantity);
    onClose();
  };

  const discountPercent = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.7 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/90 z-50 cursor-pointer"
            id="quickview-modal-backdrop"
          />

          {/* Modal Container */}
          <div className="fixed inset-0 z-51 overflow-y-auto flex items-center justify-center p-4 sm:p-6 md:p-10">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ type: 'spring', damping: 25, stiffness: 250 }}
              className="bg-zinc-950 rounded-3xl w-full max-w-4xl max-h-[90vh] overflow-hidden border border-zinc-900 relative flex flex-col md:flex-row"
              id={`quickview-modal-content-${product.id}`}
            >
              {/* Close Button */}
              <button
                onClick={onClose}
                className="absolute top-4 right-4 z-10 p-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-slate-400 hover:text-white transition-colors cursor-pointer border border-zinc-800"
                id="quickview-modal-close-btn"
              >
                <X className="w-4 h-4" />
              </button>

              {/* Left Column: Image Gallery */}
              <div className="w-full md:w-[45%] bg-zinc-950 p-6 flex flex-col justify-between border-b md:border-b-0 md:border-r border-zinc-900 max-h-[40vh] md:max-h-[90vh] overflow-y-auto">
                <div className="space-y-4">
                  {/* Large preview */}
                  <div className="relative aspect-square rounded-2xl overflow-hidden bg-zinc-900 border border-zinc-850 shadow-none">
                    <SafeImage
                      productId={product.id}
                      fallbackUrl={product.images[activeImageIdx] || product.image}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                    {discountPercent > 0 && (
                      <span className="absolute top-3 left-3 text-[10px] uppercase font-bold px-2.5 py-1 rounded-lg bg-red-500 text-white shadow-xs">
                        {discountPercent}% OFF
                      </span>
                    )}
                  </div>

                  {/* Thumbnail Selector */}
                  {product.images.length > 1 && (
                    <div className="flex gap-2.5 overflow-x-auto pb-1">
                      {product.images.map((img, idx) => (
                        <button
                          key={idx}
                          onClick={() => setActiveImageIdx(idx)}
                          className={`w-14 h-14 rounded-lg overflow-hidden border-2 cursor-pointer flex-shrink-0 transition-all ${
                            activeImageIdx === idx ? 'border-blue-500 scale-102' : 'border-zinc-800 hover:border-zinc-700'
                          }`}
                        >
                          <img src={img} alt="Thumbnail" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Selling Points Indicators */}
                <div className="hidden md:block pt-6 border-t border-zinc-900 space-y-3.5 text-xs text-slate-450">
                  <div className="flex items-center gap-2.5">
                    <ShieldCheck className="w-4 h-4 text-blue-400" />
                    <span>Premium Quality & Exact Fitting Assured</span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <Truck className="w-4 h-4 text-blue-400" />
                    <span>Free Shipping across India via Express Courier</span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <RotateCcw className="w-4 h-4 text-blue-400" />
                    <span>Hassle-Free Replacement if fitting issue</span>
                  </div>
                </div>
              </div>

              {/* Right Column: Custom Options & Checkout Controls */}
              <div className="w-full md:w-[55%] p-6 sm:p-8 overflow-y-auto max-h-[50vh] md:max-h-[90vh] flex flex-col justify-between">
                <div>
                  {/* Category & Badge */}
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest font-mono">
                      {product.category}
                    </span>
                    {product.isBestSeller && (
                      <span className="text-[9px] font-bold uppercase text-amber-450 bg-amber-950/40 px-2 py-0.5 rounded-md border border-amber-900/30">
                        Bestseller
                      </span>
                    )}
                  </div>

                  {/* Title & Ratings */}
                  <h2 className="font-display font-bold text-xl sm:text-2xl text-white tracking-tight leading-tight">
                    {product.name}
                  </h2>
                  <div className="flex items-center gap-3 mt-2 mb-4">
                    <div className="flex items-center gap-1 text-amber-500">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star key={i} className={`w-3.5 h-3.5 ${i < Math.floor(product.rating) ? 'fill-amber-500' : 'text-zinc-850'}`} />
                      ))}
                    </div>
                    <span className="text-xs font-bold text-slate-300">{product.rating}</span>
                    <span className="text-xs text-slate-500">({product.reviewsCount} verified reviews)</span>
                  </div>

                  {/* Pricing */}
                  <div className="flex items-baseline gap-2.5 mb-5 py-2 px-3 rounded-xl bg-zinc-900 border border-zinc-850 w-fit">
                    <span className="text-2xl font-black text-white">₹{product.price}</span>
                    {product.originalPrice && (
                      <span className="text-sm text-slate-500 line-through">₹{product.originalPrice}</span>
                    )}
                  </div>

                  {/* Description text */}
                  <p className="text-xs text-slate-350 leading-relaxed mb-6">
                    {product.description}
                  </p>

                  {/* -------------------- DYNAMIC CUSTOMIZATION CONTROLS -------------------- */}
                  {isPhoneCover ? (
                    <div className="space-y-4 border-t border-zinc-900 pt-5 mb-6" id="phone-cover-customizer">
                      <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">
                        Configure Your Cover Specifications:
                      </h4>

                      {/* 1. Brand Dropdown */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">Select Brand</label>
                          <select
                            value={selectedBrand}
                            onChange={(e) => setSelectedBrand(e.target.value)}
                            className="w-full text-xs py-2.5 px-3 rounded-xl border border-zinc-800 bg-zinc-900 text-white focus:bg-zinc-900 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-colors"
                            id="brand-dropdown-selector"
                          >
                            {BRANDS_AND_MODELS.map((b) => (
                              <option key={b.brand} value={b.brand} className="bg-zinc-900 text-white">
                                {b.brand}
                              </option>
                            ))}
                          </select>
                        </div>

                        {/* 2. Model Dropdown */}
                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">Select Phone Model</label>
                          <select
                            value={selectedModel}
                            onChange={(e) => setSelectedModel(e.target.value)}
                            className="w-full text-xs py-2.5 px-3 rounded-xl border border-zinc-800 bg-zinc-900 text-white focus:bg-zinc-900 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-colors"
                            id="model-dropdown-selector"
                          >
                            {activeBrandModels.map((m) => (
                              <option key={m} value={m} className="bg-zinc-900 text-white">
                                {m}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>

                      {/* 3. Color Swatch Selector */}
                      <div className="space-y-1.5">
                        <div className="flex justify-between">
                          <span className="text-xs font-semibold text-slate-300">Select Color Theme</span>
                          <span className="text-xs font-bold text-blue-400">{selectedColor}</span>
                        </div>
                        <div className="flex gap-2 flex-wrap">
                          {PHONE_COVER_COLORS.map((c) => (
                            <button
                              key={c.name}
                              onClick={() => setSelectedColor(c.name)}
                              className={`relative w-8 h-8 rounded-full border transition-all flex items-center justify-center cursor-pointer ${
                                selectedColor === c.name
                                  ? 'ring-2 ring-blue-500 ring-offset-2 ring-offset-zinc-950 scale-105'
                                  : 'border-zinc-800 hover:scale-102'
                              }`}
                              style={{
                                background: c.isClear
                                  ? 'linear-gradient(45deg, #27272a 25%, #3f3f46 25%, #3f3f46 50%, #27272a 50%, #27272a 75%, #3f3f46 75%, #3f3f46 100%)'
                                  : c.hex,
                                backgroundSize: c.isClear ? '10px 10px' : 'auto',
                              }}
                              title={c.name}
                            >
                              {selectedColor === c.name && (
                                <Check
                                  className={`w-4 h-4 ${
                                    c.name === 'Crystal Clear' || c.name === 'Sunset Gold'
                                      ? 'text-zinc-950'
                                      : 'text-white'
                                  }`}
                                />
                              )}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* 4. Material Buttons Selector */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-slate-300">Select Case Material</label>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {PHONE_COVER_MATERIALS.map((m) => (
                            <button
                              key={m}
                              onClick={() => setSelectedMaterial(m)}
                              className={`py-2 px-3 rounded-xl border text-[11px] font-medium text-left transition-all flex items-center justify-between cursor-pointer ${
                                selectedMaterial === m
                                  ? 'border-blue-500 bg-blue-950/40 text-blue-400 font-semibold'
                                  : 'border-zinc-850 bg-zinc-900/50 hover:bg-zinc-900 text-slate-400'
                              }`}
                            >
                              <span>{m}</span>
                              {selectedMaterial === m && <Check className="w-3.5 h-3.5 text-blue-400" />}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* 5. Finish Selector */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-slate-300">Select Finish Texture</label>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {PHONE_COVER_FINISHES.map((f) => (
                            <button
                              key={f}
                              onClick={() => setSelectedFinish(f)}
                              className={`py-2 px-3 rounded-xl border text-[11px] font-medium text-left transition-all flex items-center justify-between cursor-pointer ${
                                selectedFinish === f
                                  ? 'border-blue-500 bg-blue-950/40 text-blue-400 font-semibold'
                                  : 'border-zinc-850 bg-zinc-900/50 hover:bg-zinc-900 text-slate-400'
                              }`}
                            >
                              <span>{f}</span>
                              {selectedFinish === f && <Check className="w-3.5 h-3.5 text-blue-400" />}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : isTemperedGlass ? (
                    <div className="space-y-4 border-t border-zinc-900 pt-5 mb-6" id="glass-cover-customizer">
                      <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">
                        Select Your Smartphone Model:
                      </h4>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {/* 1. Brand Dropdown */}
                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">Select Brand</label>
                          <select
                            value={selectedBrand}
                            onChange={(e) => setSelectedBrand(e.target.value)}
                            className="w-full text-xs py-2.5 px-3 rounded-xl border border-zinc-800 bg-zinc-900 text-white focus:bg-zinc-900 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-colors"
                            id="glass-brand-dropdown-selector"
                          >
                            {BRANDS_AND_MODELS.map((b) => (
                              <option key={b.brand} value={b.brand} className="bg-zinc-900 text-white">
                                {b.brand}
                              </option>
                            ))}
                          </select>
                        </div>

                        {/* 2. Model Dropdown */}
                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">Select Phone Model</label>
                          <select
                            value={selectedModel}
                            onChange={(e) => setSelectedModel(e.target.value)}
                            className="w-full text-xs py-2.5 px-3 rounded-xl border border-zinc-800 bg-zinc-900 text-white focus:bg-zinc-900 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-colors"
                            id="glass-model-dropdown-selector"
                          >
                            {activeBrandModels.map((m) => (
                              <option key={m} value={m} className="bg-zinc-900 text-white">
                                {m}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>

                      {/* 3. Glass Type Dropdown */}
                      <div className="space-y-1 pt-2">
                        <label className="text-xs font-semibold text-slate-300">Select Glass Type</label>
                        <select
                          value={selectedGlassType}
                          onChange={(e) => setSelectedGlassType(e.target.value)}
                          className="w-full text-xs py-2.5 px-3 rounded-xl border border-zinc-800 bg-zinc-900 text-white focus:bg-zinc-900 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-colors"
                          id="glass-type-dropdown-selector"
                        >
                          {GLASS_TYPES.map((gt) => (
                            <option key={gt} value={gt} className="bg-zinc-900 text-white">
                              {gt}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  ) : null}
                </div>

                {/* Bottom Order Controls (Sticky bar feel) */}
                <div className="border-t border-zinc-900 pt-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-300">Specify Quantity</span>
                    <div className="flex items-center gap-1.5 bg-zinc-950 border border-zinc-850 rounded-xl p-1 shadow-none">
                      <button
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        className="w-8 h-8 rounded-lg text-slate-400 hover:bg-zinc-900 hover:text-white transition-all flex items-center justify-center font-bold text-sm cursor-pointer disabled:opacity-30"
                        disabled={quantity <= 1}
                      >
                        -
                      </button>
                      <span className="w-8 text-center text-xs font-bold text-slate-200">{quantity}</span>
                      <button
                        onClick={() => setQuantity(quantity + 1)}
                        className="w-8 h-8 rounded-lg text-slate-400 hover:bg-zinc-900 hover:text-white transition-all flex items-center justify-center font-bold text-sm cursor-pointer"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  {/* Large CTA Add to Cart button */}
                  <button
                    onClick={handleAddToCart}
                    disabled={product.stockStatus === 'out_of_stock'}
                    className={`w-full py-3.5 rounded-xl text-white text-sm font-bold shadow-none transition-all flex items-center justify-center gap-2 cursor-pointer ${
                      product.stockStatus === 'out_of_stock'
                        ? 'bg-zinc-900 text-slate-600 cursor-not-allowed'
                        : 'bg-blue-600 hover:bg-blue-700 hover:-translate-y-0.5 active:translate-y-0'
                    }`}
                    id="quickview-modal-add-to-cart-btn"
                  >
                    <ShoppingCart className="w-4 h-4" />
                    <span>
                      {product.stockStatus === 'out_of_stock'
                        ? 'Out of Stock'
                        : isPhoneCover
                        ? 'Add Customized Cover to Cart'
                        : isTemperedGlass
                        ? 'Add Tempered Glass to Cart'
                        : 'Add Accessory to Cart'}
                    </span>
                  </button>

                  {/* Estimated Delivery Note */}
                  <p className="text-[10px] text-center text-slate-500">
                    Est. dispatch within 24 Hours. Deliveries across India in 3-5 business days.
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}
