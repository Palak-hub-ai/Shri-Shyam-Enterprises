import { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import CartDrawer from './components/CartDrawer';
import QuickViewModal from './components/QuickViewModal';

// Pages
import Home from './pages/Home';
import Shop from './pages/Shop';
import ProductDetail from './pages/ProductDetail';
import About from './pages/About';
import Contact from './pages/Contact';
import Checkout from './pages/Checkout';
import CustomOrder from './pages/CustomOrder';

// Types & Data
import { Product, CartItem, SelectedOptions, Category } from './types';
import { PRODUCTS } from './data/products';

type Page = 'home' | 'shop' | 'product-detail' | 'about' | 'contact' | 'checkout' | 'custom-order';

export default function App() {
  // Global View/Router State
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [activeProductId, setActiveProductId] = useState<string>('phone-cover');
  const [navigationExtra, setNavigationExtra] = useState<Record<string, any>>({});

  // Global Cart State
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Quick View / Customize modal state
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [isQuickViewOpen, setIsQuickViewOpen] = useState(false);

  // Sync cart with localStorage for basic client-side session durability
  useEffect(() => {
    const savedCart = localStorage.getItem('shri_shyam_cart');
    if (savedCart) {
      try {
        setCartItems(JSON.parse(savedCart));
      } catch (err) {
        console.error('Failed to parse cart items from localStorage:', err);
      }
    }
  }, []);

  const saveCartToStorage = (items: CartItem[]) => {
    setCartItems(items);
    localStorage.setItem('shri_shyam_cart', JSON.stringify(items));
  };

  // Add Item to Cart Engine
  const handleAddToCart = (product: Product, options?: SelectedOptions, quantity = 1) => {
    // Unique ID generation for compound items (specifically customizable covers)
    let compoundItemId = product.id;
    if (options) {
      const parts = [
        options.brand,
        options.model,
        options.color,
        options.material,
        options.finish
      ].filter(Boolean);
      compoundItemId = `${product.id}-${parts.join('-')}`;
    }

    const updatedItems = [...cartItems];
    const existingIdx = updatedItems.findIndex((item) => item.id === compoundItemId);

    if (existingIdx > -1) {
      updatedItems[existingIdx].quantity += quantity;
    } else {
      updatedItems.push({
        id: compoundItemId,
        product,
        quantity,
        selectedOptions: options,
      });
    }

    saveCartToStorage(updatedItems);
    
    // Automatically trigger cart drawer slider open as visual action feedback
    setIsCartOpen(true);
  };

  // Update quantity count on specific cart items
  const handleUpdateQuantity = (itemId: string, delta: number) => {
    const updatedItems = cartItems
      .map((item) => {
        if (item.id === itemId) {
          const newQty = item.quantity + delta;
          return { ...item, quantity: Math.max(1, newQty) };
        }
        return item;
      });
    saveCartToStorage(updatedItems);
  };

  // Remove specific item entirely
  const handleRemoveItem = (itemId: string) => {
    const updatedItems = cartItems.filter((item) => item.id !== itemId);
    saveCartToStorage(updatedItems);
  };

  // Clear cart completely (on successful checkout redirect)
  const handleClearCart = () => {
    saveCartToStorage([]);
  };

  // Global Page router navigator callback
  const handleNavigate = (page: Page, extra?: Record<string, any>) => {
    if (extra) {
      setNavigationExtra(extra);
      if (extra.productId) {
        setActiveProductId(extra.productId);
      }
    } else {
      setNavigationExtra({});
    }
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleQuickViewTrigger = (product: Product) => {
    setQuickViewProduct(product);
    setIsQuickViewOpen(true);
  };

  // Total cart badge counter count
  const cartItemsCount = useMemo(() => {
    return cartItems.reduce((acc, item) => acc + item.quantity, 0);
  }, [cartItems]);

  return (
    <div className="flex flex-col min-h-screen bg-black selection:bg-blue-600 selection:text-white overflow-x-hidden">
      
      {/* 1. STICKY GLASSMORPHISM NAVBAR */}
      <Navbar
        currentPage={currentPage}
        onNavigate={(page) => handleNavigate(page as Page)}
        cartItemsCount={cartItemsCount}
        onCartOpen={() => setIsCartOpen(true)}
      />

      {/* 2. MAIN PAGES SPACE WITH ACCELERATED FRAMER MOTION TRANSITIONS */}
      <main className="flex-grow">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage + (navigationExtra?.productId || '')}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.35, ease: 'easeInOut' }}
          >
            {currentPage === 'home' && (
              <Home
                products={PRODUCTS}
                onAddToCart={(p) => handleAddToCart(p)}
                onQuickView={handleQuickViewTrigger}
                onNavigateToPage={(p, ext) => handleNavigate(p as Page, ext)}
              />
            )}

            {currentPage === 'shop' && (
              <Shop
                products={PRODUCTS}
                onAddToCart={(p) => handleAddToCart(p)}
                onQuickView={handleQuickViewTrigger}
                onNavigateToProduct={(id) => handleNavigate('product-detail', { productId: id })}
                initialFilters={navigationExtra as any}
              />
            )}

            {currentPage === 'product-detail' && (
              <ProductDetail
                productId={activeProductId}
                products={PRODUCTS}
                onAddToCart={handleAddToCart}
                onNavigateToProduct={(id) => handleNavigate('product-detail', { productId: id })}
                onNavigateToPage={(p, ext) => handleNavigate(p as Page, ext)}
              />
            )}

            {currentPage === 'about' && <About />}

            {currentPage === 'contact' && <Contact />}

            {currentPage === 'custom-order' && (
              <CustomOrder
                onNavigateToPage={(p) => handleNavigate(p as Page)}
              />
            )}

            {currentPage === 'checkout' && (
              <Checkout
                cartItems={cartItems}
                onNavigateToPage={(p) => handleNavigate(p as Page)}
                onClearCart={handleClearCart}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* 3. GLOBAL FOOTER STRIP */}
      <Footer onNavigate={(page) => handleNavigate(page as Page)} />

      {/* 4. SLIDING CART DRAWER SYSTEM */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onNavigateToCheckout={() => handleNavigate('checkout')}
      />

      {/* 5. INTERACTIVE PRODUCT CUSTOMIZER / QUICK-VIEW MODAL */}
      <QuickViewModal
        product={quickViewProduct}
        isOpen={isQuickViewOpen}
        onClose={() => {
          setIsQuickViewOpen(false);
          setQuickViewProduct(null);
        }}
        onAddToCart={handleAddToCart}
      />
    </div>
  );
}
