import { TIMELINE_EVENTS, STATS } from '../data/products';
import { Target, Compass, Award, CheckCircle2 } from 'lucide-react';

export default function About() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 space-y-20" id="about-page-container">
      
      {/* 1. Header Banner */}
      <div className="text-center space-y-3 max-w-2xl mx-auto">
        <div className="text-xs text-blue-400 font-bold font-mono uppercase tracking-widest">
          ESTABLISHED 2020 &bull; ACCESSORY SPECIALISTS
        </div>
        <h1 className="font-display font-black text-3xl sm:text-4xl lg:text-5xl text-white tracking-tight pb-1">
          Our Narrative & Core Philosophy
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 leading-relaxed font-sans">
          Shri Shyam Enterprises is built upon a single, pure objective: providing ultra-premium protective shields, hyper-speed adapters, and premium tech-luxury accessories without the high markups.
        </p>
      </div>

      {/* 2. Brand Story Narrative block */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        {/* Story details */}
        <div className="lg:col-span-7 space-y-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-950/40 border border-blue-900/40 text-xs font-semibold text-blue-400 font-mono uppercase">
            <span>Our Journey</span>
          </div>
          
          <h2 className="font-display font-black text-2xl sm:text-3xl text-white tracking-tight leading-snug">
            Sourcing Only the Finest. Engineered for Your Devices.
          </h2>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-sans">
            Founded in 2020 as a physical retail spot specializing in cases, we quickly realized that modern users were tired of choosing between cheap, yellowing street-covers and ridiculously expensive, overpriced brands. Smartphone screens were breaking, and local chargers were heating up, risking battery health.
          </p>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-sans">
            We chose a different path. We formed tight associations directly with verified manufacturers to source non-yellowing liquid silicones, high-grade carbon fiber molds, and advanced Gallium Nitride (GaN III) charging controllers. We focus strictly on mobile accessories—meaning 100% of our testing, resources, and customer care are dedicated to safeguarding and fueling your primary handset.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div className="flex gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-slate-100 text-xs sm:text-sm block">Strict Fit Testing</span>
                <span className="text-[11px] text-slate-400 block">Every cover model is tested with physical devices to secure exact button tactile clicks.</span>
              </div>
            </div>
            <div className="flex gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-slate-100 text-xs sm:text-sm block">Battery Safety Standards</span>
                <span className="text-[11px] text-slate-400 block">Our chargers operate smart power division to guard device batteries against spikes.</span>
              </div>
            </div>
          </div>
        </div>

        {/* Story Illustration Grid */}
        <div className="lg:col-span-5 relative">
          {/* Decorative gradients */}
          <div className="absolute inset-0 bg-radial from-blue-500/10 to-transparent blur-3xl pointer-events-none rounded-full scale-110" />
          
          <div className="relative rounded-3xl border border-zinc-800 overflow-hidden bg-zinc-900/80 p-6 sm:p-8 space-y-6 shadow-none">
            <div className="flex items-center gap-3.5 border-b border-zinc-800 pb-5">
              <div className="w-11 h-11 rounded-xl bg-blue-600 flex items-center justify-center text-white text-lg font-bold">
                S
              </div>
              <div>
                <span className="font-display font-bold text-white block text-sm sm:text-base">Shri Shyam Enterprises</span>
                <span className="text-[10px] text-slate-500 font-mono block">ESTD. 2020 IN RAJASTHAN, INDIA</span>
              </div>
            </div>

            <div className="space-y-4 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Corporate Integrity</span>
                <span className="font-bold text-blue-400">100% Sourced Directly</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Device Fitting Precision</span>
                <span className="font-bold text-blue-400">99.9% Perfect Alignment</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Fast Shipping Partners</span>
                <span className="font-bold text-blue-400">Delhivery, Bluedart, SpeedPost</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">WhatsApp Response Delay</span>
                <span className="font-bold text-blue-400">&lt; 5 Minutes Avg</span>
              </div>
            </div>

            <div className="pt-4 border-t border-zinc-800 flex items-center gap-2 justify-center text-[10px] font-bold text-slate-500 font-mono">
              <Award className="w-4 h-4 text-amber-500" />
              <span>OFFICIAL BRAND DISTRIBUTOR</span>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Mission & Vision Bento */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8" id="about-mission-section">
        <div className="p-8 rounded-3xl bg-zinc-900/80 border border-zinc-800 hover:border-blue-900/40 shadow-none space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-blue-950/40 text-blue-400 flex items-center justify-center border border-blue-900/30">
            <Target className="w-6 h-6" />
          </div>
          <h3 className="font-display font-black text-xl text-white">Our Strategic Mission</h3>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-sans">
            Our mission is to establish a secure, trustworthy e-commerce ecosystem where Indian smartphone owners can easily find high-quality, exact-fitting protective cases and adapters. We aim to remove the stress of online purchasing by offering manual, personal order checks via WhatsApp to double-check model fitting before dispatching.
          </p>
        </div>

        <div className="p-8 rounded-3xl bg-zinc-900/80 border border-zinc-800 hover:border-blue-900/40 shadow-none space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-cyan-950/40 text-cyan-400 flex items-center justify-center border border-cyan-900/30">
            <Compass className="w-6 h-6" />
          </div>
          <h3 className="font-display font-black text-xl text-white">Our Long-term Vision</h3>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-sans">
            We envision becoming the foremost tech-accessory brand for premium covers and charging solutions in the country. By sticking strictly to accessories, avoiding high brand-rentals, and centering on transparent WhatsApp communications, we want to prove that premium-designed accessories can remain universally affordable.
          </p>
        </div>
      </section>

      {/* 4. STATISTICS COUNTER */}
      <section className="bg-zinc-900/90 border border-zinc-800 text-white py-12 rounded-[30px] p-6 sm:p-12" id="about-stats-section">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center">
          {STATS.map((stat, i) => (
            <div key={i} className="space-y-1.5">
              <div className="text-3xl sm:text-4xl font-display font-black text-blue-400">
                {stat.value}
              </div>
              <div className="text-[10px] sm:text-xs text-slate-500 tracking-wider uppercase font-mono font-medium">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. TIMELINE EVENTS SECTION */}
      <section className="space-y-12" id="about-timeline-section">
        <div className="text-center space-y-3">
          <h2 className="font-display font-black text-2xl sm:text-3xl text-white tracking-tight">
            Our Key Historic Milestones
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 max-w-sm mx-auto">
            A quick chronological overview of how we evolved from a retail accessory kiosk to a premium online brand.
          </p>
        </div>

        {/* Vertical Timeline Design */}
        <div className="relative max-w-3xl mx-auto px-4 sm:px-0">
          {/* Central Line */}
          <div className="absolute left-6 sm:left-1/2 top-0 bottom-0 w-0.5 bg-zinc-800 -translate-x-1/2" />

          <div className="space-y-10 sm:space-y-14">
            {TIMELINE_EVENTS.map((event, idx) => {
              const isEven = idx % 2 === 0;
              return (
                <div key={event.year} className="relative flex flex-col sm:flex-row items-start sm:items-center">
                  
                  {/* Circle Indicator on the line */}
                  <div className="absolute left-6 sm:left-1/2 w-4 h-4 rounded-full bg-blue-500 border-4 border-zinc-950 shadow-none -translate-x-1/2 z-10" />

                  {/* Date Year Flag */}
                  <div className="pl-14 sm:pl-0 sm:absolute sm:left-1/2 sm:-translate-x-1/2 sm:-translate-y-8 text-sm font-black font-mono text-blue-400 bg-blue-950/60 border border-blue-900/50 px-3 py-1 rounded-full z-10">
                    {event.year}
                  </div>

                  {/* Left Side Content (Desktop: even index) */}
                  <div className={`w-full sm:w-[45%] pl-14 sm:pl-0 mt-3 sm:mt-0 ${isEven ? 'sm:text-right sm:pr-8' : 'sm:opacity-0 sm:pointer-events-none'}`}>
                    {isEven && (
                      <div className="space-y-1.5 p-5 rounded-2xl bg-zinc-900/80 border border-zinc-800 shadow-none">
                        <h4 className="font-display font-bold text-white text-sm sm:text-base">{event.title}</h4>
                        <p className="text-xs text-slate-400 leading-relaxed">{event.description}</p>
                      </div>
                    )}
                  </div>

                  {/* Spacer for structure */}
                  <div className="hidden sm:block w-[10%]" />

                  {/* Right Side Content (Desktop: odd index) */}
                  <div className={`w-full sm:w-[45%] pl-14 sm:pl-0 mt-2 sm:mt-0 ${!isEven ? 'sm:text-left sm:pl-8' : 'sm:opacity-0 sm:pointer-events-none'}`}>
                    {!isEven && (
                      <div className="space-y-1.5 p-5 rounded-2xl bg-zinc-900/80 border border-zinc-800 shadow-none">
                        <h4 className="font-display font-bold text-white text-sm sm:text-base">{event.title}</h4>
                        <p className="text-xs text-slate-400 leading-relaxed">{event.description}</p>
                      </div>
                    )}
                  </div>

                </div>
              );
            })}
          </div>
        </div>
      </section>

    </div>
  );
}
