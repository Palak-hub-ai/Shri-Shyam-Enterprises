import { useState, useMemo, FormEvent, ChangeEvent } from 'react';
import { Phone, Mail, MapPin, Clock, MessageSquare, Send, CheckCircle2 } from 'lucide-react';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    message: '',
  });

  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    // Simulate contact form submission
    setIsSubmitted(true);
    setFormData({ name: '', phone: '', email: '', message: '' });
    setTimeout(() => {
      setIsSubmitted(false);
    }, 5000);
  };

  const handleInputChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Pre-fill general enquiry text for standard WhatsApp chat CTA
  const generalWhatsappUrl = useMemo(() => {
    const text = "Hello Shri Shyam Enterprises, I visited your accessories store website and would like to ask some questions regarding product fittings.";
    return `https://wa.me/918949701510?text=${encodeURIComponent(text)}`;
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 space-y-16" id="contact-page-container">
      
      {/* Page header title */}
      <div className="text-center space-y-3 max-w-xl mx-auto">
        <div className="text-xs text-blue-400 font-bold font-mono uppercase tracking-widest">
          GET IN TOUCH &bull; 24/7 WHATSAPP HELP
        </div>
        <h1 className="font-display font-black text-3xl sm:text-4xl text-white tracking-tight pb-1">
          Connect With Our Specialists
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 font-sans leading-relaxed">
          Have queries regarding device compatibilities or bulk order availability? Leave us a message or jump straight onto WhatsApp chat.
        </p>
      </div>

      {/* Main Column Grid layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        
        {/* LEFT COLUMN: INTERACTIVE FORM (Col span 7) */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-zinc-900/80 rounded-3xl border border-zinc-800 p-6 sm:p-8 shadow-none space-y-6">
            <h2 className="font-display font-bold text-lg sm:text-xl text-white tracking-tight flex items-center gap-2">
              <Mail className="w-5 h-5 text-blue-400" />
              <span>Send Us an E-mail Enquiry</span>
            </h2>

            {isSubmitted ? (
              <div className="p-6 rounded-2xl bg-green-950/20 border border-green-900/30 text-green-400 flex flex-col items-center text-center gap-2.5 animate-pulse-subtle">
                <CheckCircle2 className="w-8 h-8 text-green-400" />
                <div>
                  <h4 className="font-bold text-sm sm:text-base">Enquiry Logged Successfully!</h4>
                  <p className="text-xs text-green-500 mt-1">Thank you for writing. Our customer support team will reply back to your phone or email shortly.</p>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm" id="contact-feedback-form">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Name field */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-300">Your Full Name *</label>
                    <input
                      type="text"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder="e.g. Rahul Verma"
                      className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white placeholder-slate-600 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all shadow-none"
                    />
                  </div>

                  {/* Phone field */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-300">Phone Number *</label>
                    <input
                      type="tel"
                      name="phone"
                      required
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder="e.g. +91 99999 88888"
                      className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white placeholder-slate-600 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all shadow-none"
                    />
                  </div>
                </div>

                {/* Email field */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">Email Address (Optional)</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="e.g. rahul@domain.com"
                    className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white placeholder-slate-600 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all shadow-none"
                  />
                </div>

                {/* Message field */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">Your Inquiry Message *</label>
                  <textarea
                    name="message"
                    required
                    rows={5}
                    value={formData.message}
                    onChange={handleInputChange}
                    placeholder="Write details of the phone models you have and accessories needed..."
                    className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white placeholder-slate-600 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all shadow-none resize-none"
                  />
                </div>

                {/* Submit button */}
                <button
                  type="submit"
                  className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-none transition-all cursor-pointer flex items-center justify-center gap-2"
                  id="contact-form-submit-btn"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Submit Inquiry Form</span>
                </button>
              </form>
            )}
          </div>

          {/* LARGE DIRECT WHATSAPP CTA CHAT BOX */}
          <div className="bg-gradient-to-br from-blue-700 to-cyan-600 rounded-3xl p-6 sm:p-8 text-white shadow-lg space-y-6 relative overflow-hidden">
            {/* Background elements */}
            <div className="absolute top-0 right-0 w-44 h-44 bg-white/10 rounded-full blur-2xl pointer-events-none" />
            
            <div className="space-y-3 relative z-10">
              <h3 className="font-display font-black text-xl sm:text-2xl">Prefer Instant Support?</h3>
              <p className="text-xs text-blue-50/90 leading-relaxed max-w-xl">
                Skip writing forms entirely. Tap the button below to initiate a live WhatsApp conversation directly with Shri Shyam support desk. Check item availability and pricing instantly!
              </p>
            </div>

            <a
              href={generalWhatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2.5 px-6 py-4 rounded-xl bg-white text-zinc-950 font-black text-xs hover:bg-zinc-100 shadow-md hover:-translate-y-0.5 transition-all z-10"
              id="whatsapp-chat-direct-cta"
            >
              <MessageSquare className="w-4 h-4 text-green-500 fill-green-500" />
              <span>Chat Live on WhatsApp Now</span>
            </a>
          </div>
        </div>

        {/* RIGHT COLUMN: INFRASTRUCTURE & BUSINESS DETAILS (Col span 5) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Contacts info box */}
          <div className="bg-zinc-900/80 rounded-3xl border border-zinc-800 p-6 sm:p-8 shadow-none space-y-6">
            <h2 className="font-display font-bold text-lg text-white tracking-tight pb-2 border-b border-zinc-800">
              Store Logistics Info
            </h2>

            <div className="space-y-5 text-xs text-slate-300">
              {/* Address details */}
              <div className="flex gap-3.5 items-start">
                <div className="p-2.5 rounded-xl bg-blue-950/40 text-blue-400 flex-shrink-0 border border-blue-900/30">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-white block mb-0.5">Physical Address</span>
                  <p className="leading-relaxed text-slate-400">
                    Shri Shyam Enterprises, Bajaj Road, Near Shriram Coaching, Sikar, Rajasthan - 332001, India.
                  </p>
                </div>
              </div>

              {/* Phone details */}
              <div className="flex gap-3.5 items-start border-t border-zinc-800 pt-4">
                <div className="p-2.5 rounded-xl bg-blue-950/40 text-blue-400 flex-shrink-0 border border-blue-900/30">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-white block mb-0.5">Call / WhatsApp Support</span>
                  <p className="leading-relaxed font-mono text-slate-400">
                    +91 89497 01510
                  </p>
                  <span className="text-[10px] text-slate-500 font-mono tracking-wider block mt-0.5">Response in under 5 minutes</span>
                </div>
              </div>

              {/* Email details */}
              <div className="flex gap-3.5 items-start border-t border-zinc-800 pt-4">
                <div className="p-2.5 rounded-xl bg-blue-950/40 text-blue-400 flex-shrink-0 border border-blue-900/30">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-white block mb-0.5">Sales / Bulk Email</span>
                  <p className="leading-relaxed font-mono text-slate-400">
                    support@shrishyam.com
                  </p>
                </div>
              </div>

              {/* Store Hours details */}
              <div className="flex gap-3.5 items-start border-t border-zinc-800 pt-4">
                <div className="p-2.5 rounded-xl bg-blue-950/40 text-blue-400 flex-shrink-0 border border-blue-900/30">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-white block mb-0.5">Business Hours</span>
                  <div className="space-y-0.5 leading-relaxed font-medium">
                    <div className="flex justify-between gap-6"><span>Mon - Sat:</span> <span className="font-bold text-white">10:00 AM - 08:30 PM</span></div>
                    <div className="flex justify-between gap-6"><span>Sunday:</span> <span className="font-bold text-red-400">CLOSED (Holiday)</span></div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* PREMIUM SVG MAP ILLUSTRATION */}
          <div className="bg-zinc-900/80 rounded-3xl border border-zinc-800 p-4 shadow-none space-y-3">
            <div className="flex justify-between items-center px-2">
              <span className="text-xs font-bold text-white font-mono uppercase tracking-wider">Store Location Map</span>
              <span className="inline-flex items-center gap-1.5 text-[9px] font-bold text-green-400 bg-green-950/40 px-2.5 py-0.5 rounded-full border border-green-900/40">
                <span className="h-1.5 w-1.5 rounded-full bg-green-500 animate-ping" />
                <span>ACTIVE PIN</span>
              </span>
            </div>

            {/* Premium detailed custom SVG grid map vector layout */}
            <div className="relative aspect-video w-full rounded-2xl bg-zinc-950 border border-zinc-850 overflow-hidden flex items-center justify-center">
              <svg className="absolute inset-0 w-full h-full opacity-35" viewBox="0 0 400 225" fill="none">
                {/* Simulated Street Grid Lines */}
                <line x1="20" y1="0" x2="20" y2="225" stroke="#334155" strokeWidth="1" />
                <line x1="120" y1="0" x2="120" y2="225" stroke="#334155" strokeWidth="1.5" />
                <line x1="220" y1="0" x2="220" y2="225" stroke="#334155" strokeWidth="1" />
                <line x1="320" y1="0" x2="320" y2="225" stroke="#334155" strokeWidth="1" />
                <line x1="0" y1="50" x2="400" y2="50" stroke="#334155" strokeWidth="1.5" />
                <line x1="0" y1="120" x2="400" y2="120" stroke="#334155" strokeWidth="2" strokeDasharray="3 3" />
                <line x1="0" y1="170" x2="400" y2="170" stroke="#334155" strokeWidth="1" />

                {/* Simulated Parks / Green Areas */}
                <rect x="25" y="60" width="85" height="50" rx="6" fill="#065f46" fillOpacity="0.15" />
                <rect x="230" y="10" width="80" height="35" rx="6" fill="#065f46" fillOpacity="0.15" />
                <rect x="230" y="130" width="80" height="35" rx="6" fill="#1e3a8a" fillOpacity="0.1" />

                {/* Location pin routes */}
                <path d="M 120 120 C 150 120, 200 120, 220 80" fill="none" stroke="#2563eb" strokeWidth="3" strokeLinecap="round" opacity="0.6" />
              </svg>

              {/* Target glowing pin overlay */}
              <div className="absolute top-[80px] left-[220px] -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
                {/* Pulsing rings */}
                <div className="relative">
                  <div className="w-10 h-10 bg-blue-500/30 rounded-full absolute -top-3 -left-3 animate-ping" />
                  <MapPin className="w-6 h-6 text-blue-400 fill-blue-500 drop-shadow-[0_2px_8px_rgba(37,99,235,0.5)] relative z-10" />
                </div>
                <div className="bg-zinc-900/95 text-white font-bold text-[9px] tracking-tight px-2 py-0.5 rounded border border-zinc-800 mt-1 shadow-none font-display relative z-10">
                  SHRI SHYAM
                </div>
              </div>

              {/* Standard geographic labels */}
              <div className="absolute bottom-3 left-3 text-[9px] text-slate-650 font-mono tracking-widest uppercase">
                Sikar Central Grid Map
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
