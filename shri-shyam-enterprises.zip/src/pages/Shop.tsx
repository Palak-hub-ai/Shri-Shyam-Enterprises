import { useState, useEffect, useMemo } from 'react';
import { Search, SlidersHorizontal, ArrowUpDown, RefreshCw, Smartphone } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { Product, Category } from '../types';

interface ShopProps {
  products: Product[];
  onAddToCart: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onNavigateToProduct: (productId: string) => void;
  onNavigateToPage?: (page: string) => void;
  initialFilters?: { activeCategory?: Category };
}

export default function Shop({
  products,
  onAddToCart,
  onQuickView,
  onNavigateToProduct,
  onNavigateToPage,
  initialFilters,
}: ShopProps) {
  // Filters State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category | 'All'>('All');
  const [maxPrice, setMaxPrice] = useState(2500);
  const [sortBy, setSortBy] = useState<'featured' | 'low-to-high' | 'high-to-low' | 'rating'>('featured');
  const [isMobileFiltersOpen, setIsMobileFiltersOpen] = useState(false);

  // Set active category if passed from home page redirects
  useEffect(() => {
    if (initialFilters?.activeCategory) {
      setSelectedCategory(initialFilters.activeCategory);
      // Reset scroll position
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [initialFilters]);

  // Unique categories list
  const categoriesList: (Category | 'All')[] = ['All', 'Phone Covers', 'Chargers', 'Cables', 'Earbuds', 'Tempered Glass', 'Power Banks', 'Holders'];

  // Handle resetting all filters
  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setMaxPrice(2500);
    setSortBy('featured');
  };

  // Perform filtration and sorting via memo
  const filteredProducts = useMemo(() => {
    let result = [...products];

    // Search query check
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(query) ||
          p.category.toLowerCase().includes(query) ||
          p.description.toLowerCase().includes(query)
      );
    }

    // Category filter
    if (selectedCategory !== 'All') {
      result = result.filter((p) => p.category === selectedCategory);
    }

    // Price range limit
    result = result.filter((p) => p.price <= maxPrice);

    // Sorting operations
    if (sortBy === 'low-to-high') {
      result.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'high-to-low') {
      result.sort((a, b) => b.price - a.price);
    } else if (sortBy === 'rating') {
      result.sort((a, b) => b.rating - a.rating);
    } else {
      // default: featured items first
      result.sort((a, b) => (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0));
    }

    return result;
  }, [products, searchQuery, selectedCategory, maxPrice, sortBy]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 space-y-10" id="shop-page-container">
      
      {/* Page Title & Breadcrumbs header */}
      <div className="space-y-2 text-center md:text-left">
        <div className="text-xs text-slate-500 font-medium font-mono">
          SHRI SHYAM ENTERPRISES &gt; PREMIUM CATALOG
        </div>
        <h1 className="font-display font-black text-3xl sm:text-4xl text-white tracking-tight pb-1">
          Explore Accessories Collection
        </h1>
        <p className="text-xs sm:text-sm text-slate-450 max-w-xl">
          Upgrade your device. Refine your search using category buttons and pricing configurations below. We deal in mobile accessories only.
        </p>
      </div>

      {/* Main Grid: Filters Side pane + Product grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* LEFT COLUMN: FILTERS (DESKTOP VIEW) */}
        <div className="hidden lg:block space-y-6 bg-zinc-900/80 p-6 rounded-2xl border border-zinc-800 h-fit sticky top-24 shadow-none">
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
            <span className="font-display font-bold text-white text-sm flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-blue-400" />
              <span>Filters</span>
            </span>
            <button
              onClick={handleResetFilters}
              className="text-[11px] font-bold text-slate-400 hover:text-blue-400 flex items-center gap-1 transition-colors cursor-pointer"
              title="Reset Filters"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Clear</span>
            </button>
          </div>

          {/* 1. Category Filter Pane */}
          <div className="space-y-2.5">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">
              Category
            </h3>
            <div className="flex flex-col gap-1">
              {categoriesList.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`w-full text-xs py-2 px-3 rounded-lg text-left transition-colors flex items-center justify-between cursor-pointer ${
                    selectedCategory === cat
                      ? 'bg-blue-950/40 text-blue-400 border border-blue-900/40 font-semibold'
                      : 'text-slate-300 hover:bg-zinc-800 hover:text-white'
                  }`}
                  id={`filter-category-${cat.toLowerCase().replace(' ', '-')}`}
                >
                  <span>{cat}</span>
                  {selectedCategory === cat && (
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* 2. Price Slider Pane */}
          <div className="space-y-3.5 pt-4 border-t border-zinc-800">
            <div className="flex justify-between items-center">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">
                Max Price
              </h3>
              <span className="text-xs font-bold text-blue-400 font-mono">
                ₹{maxPrice}
              </span>
            </div>
            <input
              type="range"
              min="99"
              max="2500"
              step="50"
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
              id="desktop-price-slider"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>₹99</span>
              <span>₹2,500</span>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: SEARCH + SORT + CATALOG GRID */}
        <div className="lg:col-span-3 space-y-6">
          
          {/* SEARCH BAR & SORTING OPTION CONTROLS */}
          <div className="flex flex-col sm:flex-row gap-4 justify-between bg-zinc-900/80 p-4 rounded-2xl border border-zinc-800 shadow-none">
            {/* Search Input Box */}
            <div className="relative flex-1">
              <Search className="absolute top-1/2 left-3.5 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                type="text"
                placeholder="Search phone cover, chargers, power bank..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full text-xs pl-10 pr-4 py-3 rounded-xl border border-zinc-800 bg-zinc-950/80 text-white placeholder-slate-500 focus:bg-black focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all"
                id="shop-search-input"
              />
            </div>

            {/* Sort & Mobile filter trigger */}
            <div className="flex items-center gap-2">
              {/* Mobile Filter Button */}
              <button
                onClick={() => setIsMobileFiltersOpen(true)}
                className="lg:hidden p-3 rounded-xl border border-zinc-800 bg-zinc-950 text-slate-300 hover:text-white flex items-center gap-1.5 text-xs font-medium cursor-pointer"
                id="shop-mobile-filter-trigger"
              >
                <SlidersHorizontal className="w-3.5 h-3.5 text-blue-400" />
                <span>Filters</span>
              </button>

              {/* Sort Selection Dropdown */}
              <div className="relative flex items-center gap-1.5 border border-zinc-800 rounded-xl bg-zinc-950 px-3 py-2.5 flex-1 sm:flex-initial">
                <ArrowUpDown className="w-3.5 h-3.5 text-slate-500" />
                <select
                  value={sortBy}
                  onChange={(e: any) => setSortBy(e.target.value)}
                  className="bg-transparent text-xs font-medium text-slate-300 outline-none cursor-pointer"
                  id="shop-sorting-selector"
                >
                  <option value="featured" className="bg-zinc-950 text-white">Sort: Featured</option>
                  <option value="low-to-high" className="bg-zinc-950 text-white">Price: Low to High</option>
                  <option value="high-to-low" className="bg-zinc-950 text-white">Price: High to Low</option>
                  <option value="rating" className="bg-zinc-950 text-white">Sort: By Rating</option>
                </select>
              </div>
            </div>
          </div>

          {/* ACTIVE FILTER PILOTS (DISPLAY ONLY) */}
          {(selectedCategory !== 'All' || maxPrice < 2500 || searchQuery) && (
            <div className="flex items-center gap-2 flex-wrap pb-1">
              <span className="text-[10px] text-slate-500 uppercase font-mono font-bold">Active filters:</span>
              {selectedCategory !== 'All' && (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-950/40 border border-blue-900/40 text-xs font-medium text-blue-400">
                  <span>Category: {selectedCategory}</span>
                  <button onClick={() => setSelectedCategory('All')} className="hover:text-blue-300 text-[10px] font-bold cursor-pointer">×</button>
                </span>
              )}
              {maxPrice < 2500 && (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-950/40 border border-blue-900/40 text-xs font-medium text-blue-400">
                  <span>Max Price: ₹{maxPrice}</span>
                  <button onClick={() => setMaxPrice(2500)} className="hover:text-blue-300 text-[10px] font-bold cursor-pointer">×</button>
                </span>
              )}
              {searchQuery && (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-950/40 border border-blue-900/40 text-xs font-medium text-blue-400">
                  <span>Keyword: "{searchQuery}"</span>
                  <button onClick={() => setSearchQuery('')} className="hover:text-blue-300 text-[10px] font-bold cursor-pointer">×</button>
                </span>
              )}
            </div>
          )}

          {/* PRODUCTS CATALOG GRID LAYOUT */}
          {filteredProducts.length === 0 ? (
            <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-12 text-center shadow-none">
              <div className="w-16 h-16 rounded-full bg-blue-950/40 text-blue-400 flex items-center justify-center mx-auto mb-4 border border-blue-900/30">
                <Search className="w-6 h-6" />
              </div>
              <h3 className="font-display font-bold text-lg text-white mb-1">
                No accessories match your filters
              </h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto mb-6">
                Try adjusting your search terms, changing the category, or expanding your maximum budget limit slider.
              </p>
              <button
                onClick={handleResetFilters}
                className="px-5 py-2.5 rounded-xl bg-zinc-800 hover:bg-blue-600 text-white font-semibold text-xs transition-colors cursor-pointer"
                id="reset-filters-cta"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((product) => (
                <div key={product.id} className="h-full">
                  <ProductCard
                    product={product}
                    onAddToCart={onAddToCart}
                    onQuickView={onQuickView}
                    onNavigateToProduct={onNavigateToProduct}
                  />
                </div>
              ))}
            </div>
          )}
        </div>

      </div>

      {/* MOBILE FILTERS POPUP PANEL */}
      {isMobileFiltersOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex items-end justify-center" id="mobile-filter-drawer">
          {/* Backdrop */}
          <div
            onClick={() => setIsMobileFiltersOpen(false)}
            className="absolute inset-0 bg-black/60 cursor-pointer"
          />
          {/* Content Pane */}
          <div className="relative bg-zinc-950 border-t border-zinc-900 w-full max-h-[85vh] rounded-t-3xl p-6 overflow-y-auto space-y-6 shadow-2xl z-10 animate-slide-up">
            <div className="flex justify-between items-center border-b border-zinc-900 pb-3">
              <span className="font-display font-black text-white text-base">Filter Options</span>
              <button
                onClick={() => setIsMobileFiltersOpen(false)}
                className="p-1.5 rounded-lg bg-zinc-900 text-slate-400 border border-zinc-850"
              >
                ✕
              </button>
            </div>

            {/* Category Filter inside mobile popup */}
            <div className="space-y-2.5">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">
                Category
              </h3>
              <div className="flex flex-wrap gap-2">
                {categoriesList.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`text-xs px-3.5 py-2 rounded-xl border transition-all cursor-pointer ${
                      selectedCategory === cat
                        ? 'bg-blue-600 text-white border-blue-600 font-semibold shadow-sm'
                        : 'border-zinc-800 bg-zinc-900 text-slate-350'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Price slider inside mobile popup */}
            <div className="space-y-3.5 pt-2">
              <div className="flex justify-between items-center">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">
                  Max Price
                </h3>
                <span className="text-xs font-bold text-blue-400 font-mono">
                  ₹{maxPrice}
                </span>
              </div>
              <input
                type="range"
                min="99"
                max="2500"
                step="50"
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>₹99</span>
                <span>₹2,500</span>
              </div>
            </div>

            {/* Action buttons inside mobile popup */}
            <div className="flex gap-3 pt-4 border-t border-zinc-900">
              <button
                onClick={handleResetFilters}
                className="flex-1 py-3 border border-zinc-800 bg-zinc-900 rounded-xl text-slate-350 font-bold text-xs"
              >
                Clear All
              </button>
              <button
                onClick={() => setIsMobileFiltersOpen(false)}
                className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-xs"
              >
                Apply Filters
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
