import { useState, FormEvent, ChangeEvent } from 'react';
import { ArrowLeft, MessageSquare, AlertCircle, Sparkles, Shield, PackageCheck, HelpCircle } from 'lucide-react';

interface CustomOrderProps {
  onNavigateToPage: (page: string) => void;
}

interface CustomOrderForm {
  name: string;
  phone: string;
  category: string;
  deviceDetails: string;
  accessoryName: string;
  description: string;
  colorPreference: string;
  materialPreference: string;
  referenceUrl: string;
  shippingState: string;
}

export default function CustomOrder({ onNavigateToPage }: CustomOrderProps) {
  const [form, setForm] = useState<CustomOrderForm>({
    name: '',
    phone: '',
    category: 'Premium Phone Cover',
    deviceDetails: '',
    accessoryName: '',
    description: '',
    colorPreference: '',
    materialPreference: '',
    referenceUrl: '',
    shippingState: '',
  });

  const [validationError, setValidationError] = useState('');

  const handleInputChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handlePlaceCustomOrder = (e: FormEvent) => {
    e.preventDefault();
    setValidationError('');

    // Validations
    if (!form.name.trim()) return setValidationError('Please enter your name.');
    if (!form.phone.trim() || form.phone.replace(/\D/g, '').length < 10) {
      return setValidationError('Please enter a valid 10-digit mobile number.');
    }
    if (!form.deviceDetails.trim()) {
      return setValidationError('Please specify your device brand & model (e.g., iPhone 15 Pro Max, Galaxy S24 Ultra).');
    }
    if (!form.accessoryName.trim()) {
      return setValidationError('Please enter what kind of custom product you need.');
    }
    if (!form.description.trim()) {
      return setValidationError('Please provide a short description of the item you want.');
    }

    // Generate WhatsApp Pre-filled Custom Order Message
    let message = `Hello Shri Shyam Enterprises,\n\n`;
    message += `✨ *CUSTOM PRODUCT REQUEST* ✨\n`;
    message += `I would like to order a bespoke/custom accessory that is not listed in your standard catalog:\n\n`;

    message += `• *Accessory Request:* ${form.accessoryName}\n`;
    message += `• *Category/Type:* ${form.category}\n`;
    message += `• *Device Brand & Model:* ${form.deviceDetails}\n`;
    
    if (form.colorPreference.trim()) {
      message += `• *Color Preference:* ${form.colorPreference}\n`;
    }
    if (form.materialPreference.trim()) {
      message += `• *Material/Finish Details:* ${form.materialPreference}\n`;
    }
    if (form.referenceUrl.trim()) {
      message += `• *Reference/Sample Link:* ${form.referenceUrl}\n`;
    }
    
    message += `• *Spec details & notes:* ${form.description}\n\n`;

    message += `----------------------------\n`;
    message += `*Customer Contact Information:*\n`;
    message += `• *Name:* ${form.name}\n`;
    message += `• *Phone Number:* ${form.phone}\n`;
    if (form.shippingState.trim()) {
      message += `• *Shipping State:* ${form.shippingState}\n`;
    }
    message += `----------------------------\n\n`;

    message += `Please confirm if you can source this item, the estimated pricing, and delivery timeline. Thank you.`;

    const encodedMessage = encodeURIComponent(message);
    const whatsappLink = `https://wa.me/918949701510?text=${encodedMessage}`;

    window.open(whatsappLink, '_blank');
  };

  const categories = [
    'Premium Phone Cover',
    'Special Charger / Adapter',
    'Heavy-Duty Charging Cable',
    'Tempered Glass / Lens Protector',
    'Smart Watch Strap / Case',
    'Wireless Earbuds / Headphone Case',
    'Car Mount / Desktop Holder',
    'Other Custom Request',
  ];

  const indianStates = [
    'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Goa', 'Gujarat', 
    'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh', 
    'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab', 
    'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura', 'Uttar Pradesh', 
    'Uttarakhand', 'West Bengal', 'Delhi', 'Jammu & Kashmir', 'Ladakh', 'Puducherry'
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-20 space-y-10" id="custom-order-page-container">
      
      {/* Back to shop action link */}
      <button
        onClick={() => onNavigateToPage('shop')}
        className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-blue-400 transition-colors cursor-pointer group"
        id="custom-order-back-button"
      >
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
        <span>BACK TO CATALOG</span>
      </button>

      {/* Header section */}
      <div className="space-y-3 max-w-3xl">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-950/40 border border-blue-900/30 text-blue-400 text-[10px] font-bold uppercase tracking-wider font-mono">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Bespoke Concierge Sourcing</span>
        </div>
        <h1 className="font-display font-black text-3xl sm:text-4xl text-white tracking-tight">
          Custom Sourcing & Order
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
          Can't find your specific mobile model cover, high-performance GaN adaptor, or custom-braided cable in our list? Specify the details below. Our sourcing agents will procure the highest quality luxury variant and coordinate directly with you.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        
        {/* LEFT COLUMN: BESPOKE CONFIGURATION FORM (Col span 7) */}
        <div className="lg:col-span-7">
          <div className="bg-zinc-900/80 rounded-3xl border border-zinc-800 p-6 sm:p-8 shadow-none space-y-6">
            <div className="space-y-1">
              <h2 className="font-display font-bold text-lg text-white">
                Accessory Specification Sheet
              </h2>
              <p className="text-[11px] text-slate-500">
                Provide precise device information and product details to ensure we procure the exact perfect fit.
              </p>
            </div>

            {validationError && (
              <div className="p-4 rounded-xl bg-red-950/20 border border-red-900/30 text-red-400 flex items-center gap-2 text-xs">
                <AlertCircle className="w-4.5 h-4.5 text-red-500 flex-shrink-0" />
                <span>{validationError}</span>
              </div>
            )}

            <form onSubmit={handlePlaceCustomOrder} className="space-y-5 text-xs sm:text-sm" id="custom-order-details-form">
              
              {/* Product Sourcing Type & Target Device Model */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">Accessory Category *</label>
                  <select
                    name="category"
                    required
                    value={form.category}
                    onChange={handleInputChange}
                    className="w-full text-xs py-3 px-3 rounded-xl border border-zinc-800 bg-zinc-950 text-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all"
                  >
                    {categories.map((cat) => (
                      <option key={cat} value={cat} className="bg-zinc-950 text-white">
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">Your Device Brand & Model *</label>
                  <input
                    type="text"
                    name="deviceDetails"
                    required
                    value={form.deviceDetails}
                    onChange={handleInputChange}
                    placeholder="e.g. OnePlus 12, iPhone 15 Pro, Nothing Phone 2"
                    className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white placeholder-slate-650 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all"
                  />
                </div>
              </div>

              {/* Custom Accessory Name / Design Request */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">What specific product are you looking for? *</label>
                <input
                  type="text"
                  name="accessoryName"
                  required
                  value={form.accessoryName}
                  onChange={handleInputChange}
                  placeholder="e.g. Alcantara Suede Case, 140W Multi-Port GaN Charger, 3-in-1 MagSafe Stand"
                  className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white placeholder-slate-650 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all"
                />
              </div>

              {/* Color & Material Preference */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">Preferred Color(s) (Optional)</label>
                  <input
                    type="text"
                    name="colorPreference"
                    value={form.colorPreference}
                    onChange={handleInputChange}
                    placeholder="e.g. Matte Dark Violet, Emerald Green, Clear"
                    className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white placeholder-slate-650 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">Material or Finish details (Optional)</label>
                  <input
                    type="text"
                    name="materialPreference"
                    value={form.materialPreference}
                    onChange={handleInputChange}
                    placeholder="e.g. Real Leather, Kevlar Fiber, Frosted Matte Matte Back"
                    className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white placeholder-slate-650 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all"
                  />
                </div>
              </div>

              {/* Reference URL */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">Reference Image URL or Sourcing Link (Optional)</label>
                <input
                  type="url"
                  name="referenceUrl"
                  value={form.referenceUrl}
                  onChange={handleInputChange}
                  placeholder="Paste a Pinterest link, Instagram link, or image URL if any"
                  className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white placeholder-slate-650 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all"
                />
              </div>

              {/* Full Specs & Notes */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">Describe what you need in detail *</label>
                <textarea
                  name="description"
                  required
                  rows={4}
                  value={form.description}
                  onChange={handleInputChange}
                  placeholder="e.g. I need a back cover with a strong MagSafe ring built-in. It should have aluminum camera lens bumpers and a matte finish that does not capture fingerprint smudges. If possible, I prefer raised lip corners."
                  className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white placeholder-slate-650 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all resize-none"
                />
              </div>

              <div className="pt-4 border-t border-zinc-800">
                <h3 className="font-display font-bold text-sm text-white mb-3">Your Delivery & Contact Details</h3>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-300">Your Full Name *</label>
                    <input
                      type="text"
                      name="name"
                      required
                      value={form.name}
                      onChange={handleInputChange}
                      placeholder="Name"
                      className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white placeholder-slate-650 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-300">WhatsApp Mobile Number *</label>
                    <input
                      type="tel"
                      name="phone"
                      required
                      value={form.phone}
                      onChange={handleInputChange}
                      placeholder="10-digit phone"
                      className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white placeholder-slate-650 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-300">Shipping State (Optional)</label>
                    <select
                      name="shippingState"
                      value={form.shippingState}
                      onChange={handleInputChange}
                      className="w-full text-xs py-3 px-3 rounded-xl border border-zinc-800 bg-zinc-950 text-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all"
                    >
                      <option value="" className="bg-zinc-950 text-white">Select State</option>
                      {indianStates.map((st) => (
                        <option key={st} value={st} className="bg-zinc-950 text-white">
                          {st}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="pt-4 space-y-3.5">
                <button
                  type="submit"
                  className="w-full py-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-none transition-all flex items-center justify-center gap-2 cursor-pointer"
                  id="custom-order-submit-btn"
                >
                  <MessageSquare className="w-4 h-4 fill-white/25" />
                  <span>Send Specifications to WhatsApp Sourcing</span>
                </button>
                <p className="text-[10px] text-center text-slate-500">
                  By clicking, a curated specification sheet will automatically compile. It launches WhatsApp to chat with Shri Shyam Enterprises (+91 89497 01510) so we can manually process and source your unique item.
                </p>
              </div>

            </form>
          </div>
        </div>

        {/* RIGHT COLUMN: CONCIERGE INFORMATION (Col span 5) */}
        <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-24">
          
          {/* Bento Card 1: How it works */}
          <div className="bg-zinc-900/80 rounded-3xl border border-zinc-800 p-6 space-y-5">
            <h3 className="font-display font-bold text-white text-sm flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>Sourcing Concierge Workflow</span>
            </h3>
            
            <div className="space-y-4 text-xs">
              <div className="flex gap-3">
                <div className="w-6 h-6 rounded-lg bg-blue-950 text-blue-400 border border-blue-900/60 font-mono font-bold text-[10px] flex items-center justify-center flex-shrink-0">
                  01
                </div>
                <div className="space-y-0.5">
                  <h4 className="font-bold text-slate-200">Specification Input</h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed">Fill out your target accessory's details, special color or material features, and device model.</p>
                </div>
              </div>

              <div className="flex gap-3">
                <div className="w-6 h-6 rounded-lg bg-blue-950 text-blue-400 border border-blue-900/60 font-mono font-bold text-[10px] flex items-center justify-center flex-shrink-0">
                  02
                </div>
                <div className="space-y-0.5">
                  <h4 className="font-bold text-slate-200">WhatsApp Dispatch</h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed">Instantly redirect to our business WhatsApp. Our support executive reviews the detailed specification sheet immediately.</p>
                </div>
              </div>

              <div className="flex gap-3">
                <div className="w-6 h-6 rounded-lg bg-blue-950 text-blue-400 border border-blue-900/60 font-mono font-bold text-[10px] flex items-center justify-center flex-shrink-0">
                  03
                </div>
                <div className="space-y-0.5">
                  <h4 className="font-bold text-slate-200">Global Sourcing Check</h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed">We cross-reference with our exclusive enterprise manufacturers in our retail network to locate the best premium variant of your request.</p>
                </div>
              </div>

              <div className="flex gap-3">
                <div className="w-6 h-6 rounded-lg bg-blue-950 text-blue-400 border border-blue-900/60 font-mono font-bold text-[10px] flex items-center justify-center flex-shrink-0">
                  04
                </div>
                <div className="space-y-0.5">
                  <h4 className="font-bold text-slate-200">Quote & Delivery</h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed">We quote you the direct pricing. Once approved, the item is quality checked, custom packaged, and shipped to your doorstep with Free Courier dispatch.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Bento Card 2: Guarantees */}
          <div className="bg-zinc-900/80 rounded-3xl border border-zinc-800 p-6 space-y-4">
            <h3 className="font-display font-bold text-white text-sm flex items-center gap-2">
              <Shield className="w-4 h-4 text-blue-400" />
              <span>Sourcing Quality Pledge</span>
            </h3>
            
            <ul className="space-y-3 text-xs text-slate-400">
              <li className="flex gap-2 items-start">
                <PackageCheck className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                <span><strong>No Compromise Sourcing:</strong> We strictly source only grade-A accessories with verified mechanical fitments and superior durable build.</span>
              </li>
              <li className="flex gap-2 items-start">
                <PackageCheck className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                <span><strong>UPI & COD Safety:</strong> Payment details are requested only after we confirm sourcing success and provide photographs of the sourced item.</span>
              </li>
            </ul>
          </div>

          {/* FAQ Link */}
          <div className="p-4 rounded-2xl bg-blue-950/20 border border-blue-900/35 text-[11px] text-slate-400 leading-relaxed flex gap-2">
            <HelpCircle className="w-4.5 h-4.5 text-blue-400 flex-shrink-0" />
            <p>
              Have other urgent inquiries? You can also bypass the form and text our executive directly about any custom requirement by clicking the WhatsApp floating widget.
            </p>
          </div>

        </div>

      </div>

    </div>
  );
}
