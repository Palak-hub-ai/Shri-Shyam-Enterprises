import { Smartphone, Zap, Headphones, ShieldAlert, Award, ShieldCheck, HeartHandshake, ArrowRight, MessageSquare, Star, Sparkles } from 'lucide-react';
import Hero3D from '../components/Hero3D';
import ProductCard from '../components/ProductCard';
import { Product, Category } from '../types';
import { TESTIMONIALS } from '../data/products';

interface HomeProps {
  products: Product[];
  onAddToCart: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onNavigateToPage: (page: string, extra?: Record<string, any>) => void;
}

export default function Home({
  products,
  onAddToCart,
  onQuickView,
  onNavigateToPage,
}: HomeProps) {
  // Extract featured products (up to 6)
  const featuredProducts = products.filter((p) => p.isFeatured).slice(0, 6);

  const categoriesList = [
    { name: 'Phone Covers' as Category, icon: Smartphone, count: '1000+ Models Supported', bg: 'from-blue-500/10 to-cyan-500/10', text: 'text-blue-600' },
    { name: 'Chargers' as Category, icon: Zap, count: 'Fast GaN Adapters', bg: 'from-amber-500/10 to-orange-500/10', text: 'text-amber-600' },
    { name: 'Cables' as Category, icon: ShieldAlert, count: 'Braided Type-C & Lightning', bg: 'from-emerald-500/10 to-teal-500/10', text: 'text-emerald-600' },
    { name: 'Earbuds' as Category, icon: Headphones, count: 'ANC Audio Accessories', bg: 'from-indigo-500/10 to-purple-500/10', text: 'text-indigo-600' },
    { name: 'Tempered Glass' as Category, icon: ShieldCheck, count: '9H Full Protection Screen', bg: 'from-red-500/10 to-rose-500/10', text: 'text-red-600' },
    { name: 'Power Banks' as Category, icon: Award, count: 'High-Capacity Backups', bg: 'from-cyan-500/10 to-sky-500/10', text: 'text-cyan-600' },
  ];

  const handleCategoryClick = (categoryName: Category) => {
    onNavigateToPage('shop', { activeCategory: categoryName });
  };

  const handleProductNavigate = (productId: string) => {
    onNavigateToPage('product-detail', { productId });
  };

  return (
    <div className="space-y-20 pb-16" id="home-page-container">
      
      {/* 1. HERO SECTION */}
      <section className="relative min-h-[90vh] flex items-center justify-center pt-24 pb-12 overflow-hidden bg-gradient-to-b from-blue-950/20 via-zinc-950 to-transparent">
        {/* Dynamic ambient backgrounds */}
        <div className="absolute top-20 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-radial from-blue-500/5 to-transparent blur-3xl pointer-events-none" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Hero text information */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left z-10">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-950/40 border border-blue-900/50 text-xs font-semibold text-blue-400 uppercase tracking-wider font-mono">
              <Star className="w-3.5 h-3.5 fill-blue-500" />
              <span>Premium Tech Accessories Hub</span>
            </div>
            
            <h1 className="font-display font-black text-4xl sm:text-5xl xl:text-6xl text-white tracking-tight leading-[1.1] pb-1">
              Elevate Your Mobile Experience with <span className="text-gradient">Shri Shyam</span>
            </h1>
            
            <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-sans">
              Discover a carefully handpicked collection of premium protective covers, blazing-fast charging adapters, robust braided cables, 9H tempered glass, and high-fidelity wireless audio accessories.
            </p>

            <div className="font-mono text-xs font-bold text-slate-450 tracking-wide">
              * Note: We specialize in premium mobile accessories only. No smartphones or tablets.
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                onClick={() => onNavigateToPage('shop')}
                className="w-full sm:w-auto px-8 py-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-lg hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0 transition-all cursor-pointer flex items-center justify-center gap-2"
                id="hero-shop-now-btn"
              >
                <span>Shop Premium Accessories</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => onNavigateToPage('contact')}
                className="w-full sm:w-auto px-8 py-4 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-slate-250 font-bold text-sm border border-zinc-800 transition-all cursor-pointer flex items-center justify-center"
                id="hero-contact-us-btn"
              >
                Contact Us
              </button>
            </div>
          </div>

          {/* Hero 3D interactive widget */}
          <div className="lg:col-span-5 flex justify-center z-10">
            <Hero3D />
          </div>
        </div>
      </section>

      {/* 2. FEATURED CATEGORIES SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10" id="home-categories-section">
        <div className="text-center space-y-3">
          <h2 className="font-display font-black text-2xl sm:text-3xl text-white tracking-tight">
            Explore Handpicked Categories
          </h2>
          <p className="text-xs sm:text-sm text-slate-450 max-w-lg mx-auto">
            Choose from our specialized sub-collections engineered to upgrade and safeguard your smartphone.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categoriesList.map((cat, idx) => {
            const IconComponent = cat.icon;
            return (
              <div
                key={idx}
                onClick={() => handleCategoryClick(cat.name)}
                className="group relative flex flex-col items-center text-center p-6 rounded-2xl bg-zinc-900/80 border border-zinc-800 hover:border-blue-900/50 shadow-xs cursor-pointer transition-all duration-300 hover:-translate-y-1"
                id={`home-category-card-${cat.name.toLowerCase().replace(' ', '-')}`}
              >
                {/* Background gradient glow on hover */}
                <div className="absolute inset-0 bg-gradient-to-b from-blue-500/0 to-blue-500/0 group-hover:from-blue-500/[0.02] group-hover:to-cyan-500/[0.02] rounded-2xl transition-all duration-300" />
                
                {/* Rounded Icon Box */}
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${cat.bg} flex items-center justify-center ${cat.text} group-hover:scale-105 transition-transform duration-300`}>
                  <IconComponent className="w-6 h-6" />
                </div>
                
                <h3 className="font-display font-bold text-slate-100 mt-4 text-xs sm:text-sm tracking-tight">
                  {cat.name}
                </h3>
                
                <p className="text-[10px] text-slate-500 font-medium font-mono mt-1.5 leading-snug">
                  {cat.count}
                </p>
              </div>
            );
          })}
        </div>
      </section>

      {/* 3. FEATURED PRODUCTS GRID */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10" id="home-featured-products-section">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div className="space-y-2 text-center sm:text-left">
            <h2 className="font-display font-black text-2xl sm:text-3xl text-white tracking-tight">
              Best Sellers & Trending Now
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 max-w-md">
              Check out our highly-rated protective cases, high speed GaN chargers, and premium earbuds.
            </p>
          </div>
          <button
            onClick={() => onNavigateToPage('shop')}
            className="self-center sm:self-auto flex items-center gap-1.5 px-5 py-2.5 rounded-xl border border-blue-900/50 hover:border-blue-850 bg-blue-950/30 hover:bg-blue-950/50 text-blue-400 hover:text-blue-300 text-xs font-bold transition-all cursor-pointer"
            id="home-view-all-products"
          >
            <span>Explore Entire Catalog</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {featuredProducts.map((product) => (
            <div key={product.id} className="h-full">
              <ProductCard
                product={product}
                onAddToCart={onAddToCart}
                onQuickView={onQuickView}
                onNavigateToProduct={handleProductNavigate}
              />
            </div>
          ))}
        </div>
      </section>

      {/* 4. WHY CHOOSE US VALUE PROP BAR */}
      <section className="bg-slate-900 text-white py-16 rounded-[40px] max-w-7xl mx-auto px-6 sm:px-12 relative overflow-hidden" id="home-value-propositions">
        <div className="absolute top-0 right-0 w-96 h-96 bg-radial from-blue-500/10 to-transparent blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-radial from-cyan-500/10 to-transparent blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-12">
          <div className="text-center space-y-3">
            <h2 className="font-display font-black text-2xl sm:text-3xl tracking-tight text-white">
              Why Shri Shyam Enterprises?
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto">
              We focus on uncompromising quality and dynamic, robust accessories that fit perfectly.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="space-y-3 p-5 rounded-2xl bg-white/5 border border-white/5 backdrop-blur-xs">
              <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold text-sm shadow">
                01
              </div>
              <h3 className="font-display font-bold text-base">Unmatched Quality</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                All accessories are sourced from certified manufacturers using high-grade polycarbonate, non-toxic liquid silicone, and gold-plated copper components.
              </p>
            </div>

            <div className="space-y-3 p-5 rounded-2xl bg-white/5 border border-white/5 backdrop-blur-xs">
              <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold text-sm shadow">
                02
              </div>
              <h3 className="font-display font-bold text-base">Affordable Luxury</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                We bridge the gap between premium design and budget. Get high-end finishes, double braided cables, and GaN adapters without the luxury price tags.
              </p>
            </div>

            <div className="space-y-3 p-5 rounded-2xl bg-white/5 border border-white/5 backdrop-blur-xs">
              <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold text-sm shadow">
                03
              </div>
              <h3 className="font-display font-bold text-base">Wide Fitting Range</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                We cater to all smartphones from Apple, Samsung, OnePlus, Nothing, Vivo, Xiaomi, Oppo, Realme, and Motorola. If a phone exists, we protect it!
              </p>
            </div>

            <div className="space-y-3 p-5 rounded-2xl bg-white/5 border border-white/5 backdrop-blur-xs">
              <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold text-sm shadow">
                04
              </div>
              <h3 className="font-display font-bold text-base">WhatsApp Express</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Say goodbye to cold registration forms. Directly checkout to WhatsApp chat with a pre-filled summary. Instant customer verification, personal guidance.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 4.5 BESPOKE CUSTOM SOURCING PROMO BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" id="home-custom-sourcing-promo">
        <div className="relative rounded-[40px] border border-blue-900/40 bg-zinc-950 p-8 sm:p-12 overflow-hidden flex flex-col md:flex-row items-center justify-between gap-8 shadow-2xl">
          {/* Ambient circular radial gradients for the premium feel */}
          <div className="absolute -right-20 -top-20 w-80 h-80 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -left-20 -bottom-20 w-80 h-80 bg-blue-800/10 rounded-full blur-3xl pointer-events-none" />

          {/* Texts content */}
          <div className="space-y-4 max-w-2xl text-center md:text-left relative z-10">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-950/50 border border-blue-900/40 text-blue-400 text-[10px] font-bold uppercase tracking-wider font-mono">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Bespoke Concierge Sourcing</span>
            </div>
            <h2 className="font-display font-black text-2xl sm:text-3xl text-white tracking-tight leading-tight">
              Looking for Something Specially Custom?
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              If your phone model back cover, custom watch strap, or high-output charging adapter isn't listed in our active catalog, our sourcing specialists can locate and procure it directly from our enterprise manufacturer network. 
            </p>
          </div>

          {/* Action trigger button */}
          <div className="flex-shrink-0 relative z-10">
            <button
              onClick={() => onNavigateToPage('custom-order')}
              className="px-6 py-4 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-lg shadow-blue-650/20 transition-all flex items-center gap-2 cursor-pointer group"
              id="home-custom-promo-cta"
            >
              <span>Custom Sourcing Sheet</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      {/* 5. TESTIMONIALS SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10" id="home-testimonials-section">
        <div className="text-center space-y-3">
          <h2 className="font-display font-black text-2xl sm:text-3xl text-white tracking-tight">
            Trusted by Mobile Lovers
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 max-w-sm mx-auto">
            See what our verified buyers say about our phone cover fitting and super fast chargers.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          {TESTIMONIALS.map((review) => (
            <div
              key={review.id}
              className="p-6 rounded-2xl border border-zinc-800 bg-zinc-900/80 shadow-xs relative flex flex-col justify-between"
              id={`home-testimonial-card-${review.id}`}
            >
              <div className="space-y-4">
                {/* Stars and icon quote */}
                <div className="flex items-center justify-between">
                  <div className="flex gap-0.5 text-amber-500">
                    {Array.from({ length: review.rating }).map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-500 text-amber-500" />
                    ))}
                  </div>
                  <MessageSquare className="w-4 h-4 text-zinc-700" />
                </div>
                {/* Comment */}
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed italic">
                  "{review.comment}"
                </p>
              </div>

              {/* Author Info */}
              <div className="mt-6 pt-4 border-t border-zinc-800/60 flex items-center justify-between">
                <div>
                  <h4 className="font-display font-bold text-slate-100 text-xs sm:text-sm">{review.name}</h4>
                  <p className="text-[10px] text-slate-500 font-mono tracking-wider uppercase">{review.role}</p>
                </div>
                <span className="text-[10px] text-slate-500 font-mono">{review.date}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
}
