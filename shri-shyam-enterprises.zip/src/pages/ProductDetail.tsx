import { useState, useEffect, useMemo, CSSProperties, MouseEvent } from 'react';
import { Star, ShoppingCart, Check, ShieldCheck, Truck, RotateCcw, ArrowLeft, ZoomIn, Smartphone } from 'lucide-react';
import { Product, SelectedOptions, Category } from '../types';
import { BRANDS_AND_MODELS, PHONE_COVER_COLORS, PHONE_COVER_MATERIALS, PHONE_COVER_FINISHES, GLASS_TYPES } from '../data/products';
import SafeImage from '../components/SafeImage';

interface ProductDetailProps {
  productId: string;
  products: Product[];
  onAddToCart: (product: Product, options?: SelectedOptions, qty?: number) => void;
  onNavigateToProduct: (productId: string) => void;
  onNavigateToPage: (page: string, extra?: Record<string, any>) => void;
}

export default function ProductDetail({
  productId,
  products,
  onAddToCart,
  onNavigateToProduct,
  onNavigateToPage,
}: ProductDetailProps) {
  // Find current active product
  const product = useMemo(() => {
    return products.find((p) => p.id === productId) || products[0];
  }, [products, productId]);

  const isPhoneCover = product.id === 'phone-cover';
  const isTemperedGlass = product.id === 'tempered-glass-apex';

  // State for Custom Cover
  const [selectedBrand, setSelectedBrand] = useState(BRANDS_AND_MODELS[0].brand);
  const [selectedModel, setSelectedModel] = useState(BRANDS_AND_MODELS[0].models[0]);
  const [selectedColor, setSelectedColor] = useState(PHONE_COVER_COLORS[0].name);
  const [selectedMaterial, setSelectedMaterial] = useState(PHONE_COVER_MATERIALS[0]);
  const [selectedFinish, setSelectedFinish] = useState(PHONE_COVER_FINISHES[0]);
  const [selectedGlassType, setSelectedGlassType] = useState(GLASS_TYPES[0]);

  // Gallery states
  const [activeImageIdx, setActiveImageIdx] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [zoomStyle, setZoomStyle] = useState<CSSProperties>({ transform: 'scale(1)' });

  // Reset states when product changes
  useEffect(() => {
    setQuantity(1);
    setActiveImageIdx(0);
    setZoomStyle({ transform: 'scale(1)' });
    if (isPhoneCover || isTemperedGlass) {
      setSelectedBrand(BRANDS_AND_MODELS[0].brand);
      setSelectedModel(BRANDS_AND_MODELS[0].models[0]);
      setSelectedColor(PHONE_COVER_COLORS[0].name);
      setSelectedMaterial(PHONE_COVER_MATERIALS[0]);
      setSelectedFinish(PHONE_COVER_FINISHES[0]);
      setSelectedGlassType(GLASS_TYPES[0]);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [product, isPhoneCover, isTemperedGlass]);

  // Update models dropdown dynamically when brand changes
  useEffect(() => {
    if (isPhoneCover || isTemperedGlass) {
      const match = BRANDS_AND_MODELS.find((b) => b.brand === selectedBrand);
      if (match && match.models.length > 0) {
        setSelectedModel(match.models[0]);
      }
    }
  }, [selectedBrand, isPhoneCover, isTemperedGlass]);

  const activeBrandModels = BRANDS_AND_MODELS.find((b) => b.brand === selectedBrand)?.models || [];

  // Hover Zoom effect for premium product inspection
  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    const { left, top, width, height } = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - left) / width) * 100;
    const y = ((e.clientY - top) / height) * 100;
    setZoomStyle({
      transform: 'scale(1.6)',
      transformOrigin: `${x}% ${y}%`,
    });
  };

  const handleMouseLeave = () => {
    setZoomStyle({ transform: 'scale(1)' });
  };

  const handleAddToCart = () => {
    const configOptions: SelectedOptions | undefined = isPhoneCover
      ? {
          brand: selectedBrand,
          model: selectedModel,
          color: selectedColor,
          material: selectedMaterial,
          finish: selectedFinish,
        }
      : isTemperedGlass
      ? {
          brand: selectedBrand,
          model: selectedModel,
          glassType: selectedGlassType,
        }
      : undefined;

    onAddToCart(product, configOptions, quantity);
  };

  // Filter 3 related accessories from other categories
  const relatedProducts = useMemo(() => {
    return products
      .filter((p) => p.id !== product.id && p.category !== product.category)
      .slice(0, 3);
  }, [products, product]);

  const discountPercent = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-24 space-y-16" id="product-detail-page-container">
      
      {/* Back button link */}
      <button
        onClick={() => onNavigateToPage('shop')}
        className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-blue-400 transition-colors cursor-pointer group"
        id="detail-back-button"
      >
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
        <span>BACK TO ACCESSORIES SHOP</span>
      </button>

      {/* Main Column: Details Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        
        {/* 1. Left Gallery (Col span 5) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="space-y-3">
            {/* Main Interactive Zoomable image container */}
            <div
              onMouseMove={handleMouseMove}
              onMouseLeave={handleMouseLeave}
              className="relative aspect-square rounded-3xl overflow-hidden bg-zinc-900 border border-zinc-800 shadow-none cursor-zoom-in"
              id="detail-image-viewer"
            >
              <SafeImage
                productId={product.id}
                fallbackUrl={product.images[activeImageIdx] || product.image}
                alt={product.name}
                style={zoomStyle}
                className="w-full h-full object-cover transition-transform duration-100 ease-out"
              />
              
              {/* Overlay Zoom Hint Icon */}
              <div className="absolute bottom-4 right-4 p-2 rounded-xl bg-black/60 text-white backdrop-blur-xs pointer-events-none">
                <ZoomIn className="w-4 h-4" />
              </div>
              
              {discountPercent > 0 && (
                <span className="absolute top-4 left-4 text-[10px] uppercase font-bold tracking-wider px-2.5 py-1 rounded-lg bg-red-500 text-white shadow">
                  {discountPercent}% OFF
                </span>
              )}
            </div>

            {/* Thumbnails list */}
            {product.images.length > 1 && (
              <div className="flex gap-3 overflow-x-auto pb-1">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIdx(idx)}
                    className={`w-18 h-18 rounded-xl overflow-hidden border-2 cursor-pointer flex-shrink-0 transition-all ${
                      activeImageIdx === idx ? 'border-blue-500 shadow-md scale-102' : 'border-zinc-800 hover:border-zinc-700 bg-zinc-950'
                    }`}
                  >
                    <img src={img} alt="Thumbnail View" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Core Trust checklist */}
          <div className="p-5 rounded-2xl bg-zinc-900/50 border border-zinc-800 space-y-3.5 text-xs text-slate-300">
            <div className="flex items-center gap-3">
              <ShieldCheck className="w-4.5 h-4.5 text-blue-400 flex-shrink-0" />
              <div>
                <span className="font-bold text-slate-100 block">Premium Grade Material</span>
                <span className="text-[11px] text-slate-400 block">Non-fading silicone, heavy armor impact-absorbers, braided Kevlar.</span>
              </div>
            </div>
            <div className="flex items-center gap-3 border-t border-zinc-800/80 pt-3">
              <Truck className="w-4.5 h-4.5 text-blue-400 flex-shrink-0" />
              <div>
                <span className="font-bold text-slate-100 block">Free Courier Service</span>
                <span className="text-[11px] text-slate-400 block">Tracked shipping across India with reliable logistics partners.</span>
              </div>
            </div>
            <div className="flex items-center gap-3 border-t border-zinc-800/80 pt-3">
              <RotateCcw className="w-4.5 h-4.5 text-blue-400 flex-shrink-0" />
              <div>
                <span className="font-bold text-slate-100 block">Exact Model Fitting Guarantee</span>
                <span className="text-[11px] text-slate-400 block">We replace the cover instantly if any size error occurs.</span>
              </div>
            </div>
          </div>
        </div>

        {/* 2. Right Custom Configuration & Details (Col span 7) */}
        <div className="lg:col-span-7 space-y-8">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest font-mono">
                {product.category}
              </span>
              {product.isBestSeller && (
                <span className="text-[9px] font-bold uppercase text-amber-400 bg-amber-950/40 px-2 py-0.5 rounded-md border border-amber-900/30">
                  Bestseller
                </span>
              )}
            </div>
            
            <h1 className="font-display font-black text-2xl sm:text-3xl text-white tracking-tight leading-tight">
              {product.name}
            </h1>

            {/* Star ratings */}
            <div className="flex items-center gap-3 mt-2">
              <div className="flex items-center gap-0.5 text-amber-500">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className={`w-4 h-4 ${i < Math.floor(product.rating) ? 'fill-amber-500 text-amber-500' : 'text-zinc-800'}`} />
                ))}
              </div>
              <span className="text-xs font-bold text-slate-200">{product.rating}</span>
              <span className="text-xs text-slate-550">({product.reviewsCount} verified user reviews)</span>
            </div>
          </div>

          {/* Budget block */}
          <div className="flex items-baseline gap-3 py-3 px-4 rounded-2xl bg-zinc-900 border border-zinc-800 w-fit">
            <span className="text-3xl font-black text-white">₹{product.price}</span>
            {product.originalPrice && (
              <span className="text-sm text-slate-500 line-through">₹{product.originalPrice}</span>
            )}
            <span className="text-xs text-green-400 font-bold ml-2">FREE SHIPPING INCLUDED</span>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">Description</h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {product.description}
            </p>
          </div>

          {/* Key Bullet Features */}
          <div className="space-y-3.5 pt-4 border-t border-zinc-800">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">Highlights & Features</h3>
            <ul className="space-y-2.5">
              {product.features.map((feat, i) => (
                <li key={i} className="flex items-start gap-2.5 text-xs text-slate-300">
                  <span className="w-5 h-5 rounded-full bg-blue-950/40 border border-blue-900/40 text-blue-400 flex items-center justify-center font-bold text-[10px] mt-0.5 flex-shrink-0">
                    {i + 1}
                  </span>
                  <span className="leading-relaxed">{feat}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* -------------------- DYNAMIC CUSTOMIZATION FORM -------------------- */}
          {isPhoneCover && (
            <div className="space-y-5 border-t border-zinc-800 pt-6" id="detail-page-case-customizer">
              <div className="bg-blue-950/20 border border-blue-900/30 rounded-2xl p-4 sm:p-5 space-y-4">
                <h3 className="text-xs font-black text-blue-400 uppercase tracking-wider font-mono flex items-center gap-1.5">
                  <Smartphone className="w-4 h-4" />
                  <span>Customize Your Phone Cover Requirements:</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Brand select */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-300">Phone Brand</label>
                    <select
                      value={selectedBrand}
                      onChange={(e) => setSelectedBrand(e.target.value)}
                      className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-colors shadow-none"
                      id="detail-brand-selector"
                    >
                      {BRANDS_AND_MODELS.map((b) => (
                        <option key={b.brand} value={b.brand} className="bg-zinc-950 text-white">
                          {b.brand}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Model select */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-300">Phone Model</label>
                    <select
                      value={selectedModel}
                      onChange={(e) => setSelectedModel(e.target.value)}
                      className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-colors shadow-none"
                      id="detail-model-selector"
                    >
                      {activeBrandModels.map((m) => (
                        <option key={m} value={m} className="bg-zinc-950 text-white">
                          {m}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Color swatches */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-slate-300">Color Variant</span>
                    <span className="text-xs font-black text-blue-400">{selectedColor}</span>
                  </div>
                  <div className="flex gap-2.5 flex-wrap">
                    {PHONE_COVER_COLORS.map((c) => (
                      <button
                        key={c.name}
                        onClick={() => setSelectedColor(c.name)}
                        className={`relative w-9 h-9 rounded-full border transition-all flex items-center justify-center cursor-pointer ${
                          selectedColor === c.name
                            ? 'ring-2 ring-blue-500 ring-offset-2 ring-offset-zinc-900 scale-105 shadow-sm'
                            : 'border-zinc-750 hover:scale-102'
                        }`}
                        style={{
                          background: c.isClear
                             ? 'linear-gradient(45deg, #27272a 25%, #3f3f46 25%, #3f3f46 50%, #27272a 50%, #27272a 75%, #3f3f46 75%, #3f3f46 100%)'
                            : c.hex,
                          backgroundSize: c.isClear ? '10px 10px' : 'auto',
                        }}
                        title={c.name}
                      >
                        {selectedColor === c.name && (
                          <Check
                            className={`w-4 h-4 ${
                              c.name === 'Crystal Clear' || c.name === 'Sunset Gold' ? 'text-zinc-900' : 'text-white'
                            }`}
                          />
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Material Option */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-300 block">Case Material</label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {PHONE_COVER_MATERIALS.map((m) => (
                      <button
                        key={m}
                        onClick={() => setSelectedMaterial(m)}
                        className={`py-2.5 px-4 rounded-xl border text-[11px] font-semibold text-left transition-all flex items-center justify-between cursor-pointer ${
                          selectedMaterial === m
                            ? 'border-blue-500 bg-blue-950/40 text-blue-400 font-bold shadow-sm'
                            : 'border-zinc-850 bg-zinc-900/40 hover:bg-zinc-900 text-slate-400'
                        }`}
                      >
                        <span>{m}</span>
                        {selectedMaterial === m && <Check className="w-3.5 h-3.5 text-blue-400" />}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Finish Options */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-300 block">Finish Texture</label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {PHONE_COVER_FINISHES.map((f) => (
                      <button
                        key={f}
                        onClick={() => setSelectedFinish(f)}
                        className={`py-2.5 px-4 rounded-xl border text-[11px] font-semibold text-left transition-all flex items-center justify-between cursor-pointer ${
                          selectedFinish === f
                            ? 'border-blue-500 bg-blue-950/40 text-blue-400 font-bold shadow-sm'
                            : 'border-zinc-850 bg-zinc-900/40 hover:bg-zinc-900 text-slate-400'
                        }`}
                      >
                        <span>{f}</span>
                        {selectedFinish === f && <Check className="w-3.5 h-3.5 text-blue-400" />}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {isTemperedGlass && (
            <div className="space-y-5 border-t border-zinc-800 pt-6" id="detail-page-glass-customizer">
              <div className="bg-blue-950/20 border border-blue-900/30 rounded-2xl p-4 sm:p-5 space-y-4">
                <h3 className="text-xs font-black text-blue-400 uppercase tracking-wider font-mono flex items-center gap-1.5">
                  <Smartphone className="w-4 h-4" />
                  <span>Select Your Smartphone Model:</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Brand select */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-300">Phone Brand</label>
                    <select
                      value={selectedBrand}
                      onChange={(e) => setSelectedBrand(e.target.value)}
                      className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-colors shadow-none"
                      id="detail-glass-brand-selector"
                    >
                      {BRANDS_AND_MODELS.map((b) => (
                        <option key={b.brand} value={b.brand} className="bg-zinc-950 text-white">
                          {b.brand}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Model select */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-300">Phone Model</label>
                    <select
                      value={selectedModel}
                      onChange={(e) => setSelectedModel(e.target.value)}
                      className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-colors shadow-none"
                      id="detail-glass-model-selector"
                    >
                      {activeBrandModels.map((m) => (
                        <option key={m} value={m} className="bg-zinc-950 text-white">
                          {m}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Glass Type select */}
                <div className="space-y-1 border-t border-zinc-800/60 pt-4 mt-2">
                  <label className="text-xs font-bold text-slate-300">Glass Type & Protection Style</label>
                  <select
                    value={selectedGlassType}
                    onChange={(e) => setSelectedGlassType(e.target.value)}
                    className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-colors shadow-none"
                    id="detail-glass-type-selector"
                  >
                    {GLASS_TYPES.map((gt) => (
                      <option key={gt} value={gt} className="bg-zinc-950 text-white">
                        {gt}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Technical Specifications table */}
          <div className="space-y-3.5 pt-6 border-t border-zinc-800">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">Technical Specifications</h3>
            <div className="rounded-2xl border border-zinc-800 bg-zinc-900/50 overflow-hidden text-xs">
              {Object.entries(product.specs).map(([key, val], idx) => (
                <div
                  key={key}
                  className={`grid grid-cols-1 sm:grid-cols-3 p-3.5 gap-2 ${
                    idx !== Object.keys(product.specs).length - 1 ? 'border-b border-zinc-800/80' : ''
                  }`}
                >
                  <span className="font-bold text-slate-300 sm:col-span-1">{key}</span>
                  <span className="text-slate-400 sm:col-span-2">{val}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Add to Cart Actions Block (Desktop view) */}
          <div className="hidden sm:flex items-center gap-6 border-t border-zinc-800 pt-6">
            <div className="space-y-1">
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider font-mono block">QUANTITY</span>
              <div className="flex items-center gap-1.5 bg-zinc-950 border border-zinc-850 rounded-xl p-1 shadow-inner">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-9 h-9 rounded-lg text-slate-400 hover:bg-zinc-900 hover:text-white transition-all flex items-center justify-center font-bold text-sm cursor-pointer disabled:opacity-30"
                  disabled={quantity <= 1}
                >
                  -
                </button>
                <span className="w-8 text-center text-xs font-bold text-slate-200">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-9 h-9 rounded-lg text-slate-400 hover:bg-zinc-900 hover:text-white transition-all flex items-center justify-center font-bold text-sm cursor-pointer"
                >
                  +
                </button>
              </div>
            </div>

            <div className="flex-1 pt-5">
              <button
                onClick={handleAddToCart}
                disabled={product.stockStatus === 'out_of_stock'}
                className={`w-full py-4 rounded-xl text-white font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  product.stockStatus === 'out_of_stock'
                    ? 'bg-zinc-800 text-slate-500 cursor-not-allowed'
                    : 'bg-blue-600 hover:bg-blue-700 hover:-translate-y-0.5 active:translate-y-0'
                }`}
                id="desktop-add-to-cart"
              >
                <ShoppingCart className="w-4 h-4" />
                <span>
                  {product.stockStatus === 'out_of_stock'
                    ? 'Out of Stock'
                    : isPhoneCover
                    ? 'Add Custom Cover to Cart'
                    : isTemperedGlass
                    ? 'Add Tempered Glass to Cart'
                    : 'Add Accessory to Cart'}
                </span>
              </button>
            </div>
          </div>

        </div>
      </div>

      {/* 3. RELATED ACCESSORIES SECTION */}
      <section className="space-y-8 pt-10 border-t border-zinc-800">
        <div className="space-y-2">
          <h2 className="font-display font-black text-xl sm:text-2xl text-white tracking-tight">
            Complete Your Setup: Related Accessories
          </h2>
          <p className="text-xs text-slate-450">
            Highly recommended accessories from our catalog that sync beautifully with your device.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          {relatedProducts.map((p) => (
            <div
              key={p.id}
              onClick={() => onNavigateToProduct(p.id)}
              className="group cursor-pointer flex gap-4 p-4 rounded-2xl border border-zinc-800 bg-zinc-900/80 hover:border-blue-900/40 transition-all duration-300"
            >
              <div className="w-16 h-16 rounded-xl overflow-hidden bg-zinc-950 flex-shrink-0 border border-zinc-850">
                <img src={p.image} alt={p.name} referrerPolicy="no-referrer" className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
              </div>
              <div className="flex flex-col justify-center">
                <span className="text-[9px] font-bold text-blue-400 uppercase tracking-widest font-mono">{p.category}</span>
                <h4 className="font-semibold text-white text-xs sm:text-sm leading-snug line-clamp-1 group-hover:text-blue-400 transition-colors">{p.name}</h4>
                <div className="flex items-center gap-2 mt-1">
                  <span className="font-bold text-slate-200 text-xs">₹{p.price}</span>
                  {p.originalPrice && <span className="text-[10px] text-slate-500 line-through">₹{p.originalPrice}</span>}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* -------------------- HIGH PRIORITY MOBILE STICKY BOTTOM BAR -------------------- */}
      <div 
        className="fixed bottom-0 left-0 right-0 z-30 sm:hidden bg-zinc-950/95 border-t border-zinc-900 backdrop-blur-md p-4 shadow-none flex items-center justify-between gap-4"
        id="mobile-sticky-action-bar"
      >
        <div className="flex-1 min-w-0">
          <h4 className="text-white font-bold text-xs truncate leading-snug">
            {product.name}
          </h4>
          <div className="flex items-baseline gap-1.5">
            <span className="text-sm font-black text-blue-400">₹{product.price * quantity}</span>
            {quantity > 1 && (
              <span className="text-[10px] text-slate-500">({quantity}x)</span>
            )}
          </div>
        </div>

        {/* Action Button */}
        <button
          onClick={handleAddToCart}
          disabled={product.stockStatus === 'out_of_stock'}
          className={`px-4.5 py-3 rounded-xl font-bold text-xs text-white shadow flex items-center gap-1.5 cursor-pointer flex-shrink-0 ${
            product.stockStatus === 'out_of_stock'
              ? 'bg-zinc-900 text-slate-500 cursor-not-allowed'
              : 'bg-blue-600 hover:bg-blue-700'
          }`}
          id="mobile-sticky-add-to-cart-btn"
        >
          <ShoppingCart className="w-3.5 h-3.5" />
          <span>{isPhoneCover ? 'Configure' : 'Add to Cart'}</span>
        </button>
      </div>

    </div>
  );
}
