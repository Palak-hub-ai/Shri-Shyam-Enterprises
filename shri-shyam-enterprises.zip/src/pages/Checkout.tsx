import { useState, useMemo, FormEvent, ChangeEvent } from 'react';
import { ShoppingBag, Landmark, ArrowLeft, MessageSquare, AlertCircle } from 'lucide-react';
import { CartItem, CheckoutDetails } from '../types';
import SafeImage from '../components/SafeImage';

interface CheckoutProps {
  cartItems: CartItem[];
  onNavigateToPage: (page: string) => void;
  onClearCart: () => void;
}

export default function Checkout({ cartItems, onNavigateToPage, onClearCart }: CheckoutProps) {
  const [details, setDetails] = useState<CheckoutDetails>({
    name: '',
    phone: '',
    email: '',
    address: '',
    city: '',
    state: '',
    pinCode: '',
    notes: '',
  });

  const [validationError, setValidationError] = useState('');

  const subtotal = useMemo(() => {
    return cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  }, [cartItems]);

  const handleInputChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setDetails((prev) => ({ ...prev, [name]: value }));
  };

  const handlePlaceOrder = (e: FormEvent) => {
    e.preventDefault();
    setValidationError('');

    // Form validations
    if (!details.name.trim()) return setValidationError('Please enter your full name.');
    if (!details.phone.trim() || details.phone.replace(/\D/g, '').length < 10) {
      return setValidationError('Please enter a valid 10-digit mobile number.');
    }
    if (!details.address.trim()) return setValidationError('Please specify your complete delivery address.');
    if (!details.city.trim()) return setValidationError('Please enter your delivery city.');
    if (!details.state.trim()) return setValidationError('Please select or specify your delivery state.');
    if (!details.pinCode.trim() || details.pinCode.replace(/\D/g, '').length !== 6) {
      return setValidationError('Please enter a valid 6-digit PIN Code.');
    }

    if (cartItems.length === 0) {
      return setValidationError('Your cart is empty. Please add accessories before placing an order.');
    }

    // Generate Pre-filled Message Summary
    let message = `Hello Shri Shyam Enterprises,\n\n`;
    message += `I would like to place an order for the following mobile accessories:\n\n`;

    cartItems.forEach((item) => {
      message += `• ${item.product.name}\n`;
      if (item.selectedOptions) {
        if (item.selectedOptions.brand) {
          message += `  Brand: ${item.selectedOptions.brand}\n`;
        }
        if (item.selectedOptions.model) {
          message += `  Model: ${item.selectedOptions.model}\n`;
        }
        if (item.selectedOptions.color) {
          message += `  Color: ${item.selectedOptions.color}\n`;
        }
        if (item.selectedOptions.material) {
          message += `  Material: ${item.selectedOptions.material}\n`;
        }
        if (item.selectedOptions.finish) {
          message += `  Finish: ${item.selectedOptions.finish}\n`;
        }
        if (item.selectedOptions.glassType) {
          message += `  Glass Type: ${item.selectedOptions.glassType}\n`;
        }
      }
      message += `  Quantity: ${item.quantity}\n`;
      message += `  Subtotal: ₹${item.product.price * item.quantity}\n\n`;
    });

    message += `----------------------------\n`;
    message += `Grand Total: ₹${subtotal}\n`;
    message += `Shipping: FREE DELIVERY\n`;
    message += `----------------------------\n\n`;

    message += `Customer Details:\n`;
    message += `Name: ${details.name}\n`;
    message += `Phone: ${details.phone}\n`;
    if (details.email) {
      message += `Email: ${details.email}\n`;
    }
    message += `Address: ${details.address}, ${details.city}, ${details.state} - ${details.pinCode}\n`;
    
    if (details.notes?.trim()) {
      message += `Notes: ${details.notes}\n`;
    }

    message += `\nPlease confirm availability and the total price. Thank you.`;

    // Properly URL-encode the string
    const encodedMessage = encodeURIComponent(message);
    const whatsappLink = `https://wa.me/918949701510?text=${encodedMessage}`;

    // Clear cart locally & trigger redirection
    onClearCart();
    window.open(whatsappLink, '_blank');
  };

  const indianStates = [
    'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Goa', 'Gujarat', 
    'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh', 
    'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab', 
    'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura', 'Uttar Pradesh', 
    'Uttarakhand', 'West Bengal', 'Delhi', 'Jammu & Kashmir', 'Ladakh', 'Puducherry'
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 space-y-10" id="checkout-page-container">
      
      {/* Back to shop action link */}
      <button
        onClick={() => onNavigateToPage('shop')}
        className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-blue-400 transition-colors cursor-pointer group"
        id="checkout-back-button"
      >
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
        <span>BACK TO SHOPPING CART</span>
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        
        {/* LEFT COLUMN: CUSTOMER DETAILS FORM (Col span 7) */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-zinc-900/80 rounded-3xl border border-zinc-800 p-6 sm:p-8 shadow-none space-y-6">
            <div className="space-y-1">
              <h1 className="font-display font-black text-2xl text-white tracking-tight">
                Secure WhatsApp Checkout
              </h1>
              <p className="text-xs text-slate-400">
                Provide your shipment coordinates. Your order summary will compile automatically to launch WhatsApp chat for confirmation.
              </p>
            </div>

            {validationError && (
              <div className="p-4 rounded-xl bg-red-950/20 border border-red-900/30 text-red-400 flex items-center gap-2 text-xs">
                <AlertCircle className="w-4.5 h-4.5 text-red-500 flex-shrink-0" />
                <span>{validationError}</span>
              </div>
            )}

            <form onSubmit={handlePlaceOrder} className="space-y-4 text-xs sm:text-sm" id="checkout-form-details">
              {/* Name & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">Full Name *</label>
                  <input
                    type="text"
                    name="name"
                    required
                    value={details.name}
                    onChange={handleInputChange}
                    placeholder="Enter full name"
                    className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white placeholder-slate-650 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all shadow-none"
                    id="checkout-input-name"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">Phone Number *</label>
                  <input
                    type="tel"
                    name="phone"
                    required
                    value={details.phone}
                    onChange={handleInputChange}
                    placeholder="10-digit mobile number"
                    className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white placeholder-slate-650 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all shadow-none"
                    id="checkout-input-phone"
                  />
                </div>
              </div>

              {/* Email Address */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">Email Address (Optional)</label>
                <input
                  type="email"
                  name="email"
                  value={details.email || ''}
                  onChange={handleInputChange}
                  placeholder="e.g. buyer@example.com"
                  className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white placeholder-slate-655 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all shadow-none"
                  id="checkout-input-email"
                />
              </div>

              {/* Delivery Address */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">Complete Delivery Address *</label>
                <input
                  type="text"
                  name="address"
                  required
                  value={details.address}
                  onChange={handleInputChange}
                  placeholder="House No, Building, Area Road, Landmark"
                  className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white placeholder-slate-650 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all shadow-none"
                  id="checkout-input-address"
                />
              </div>

              {/* City, State & PIN */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">City *</label>
                  <input
                    type="text"
                    name="city"
                    required
                    value={details.city}
                    onChange={handleInputChange}
                    placeholder="City"
                    className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white placeholder-slate-650 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all shadow-none"
                    id="checkout-input-city"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">State *</label>
                  <select
                    name="state"
                    required
                    value={details.state}
                    onChange={handleInputChange}
                    className="w-full text-xs py-3 px-3 rounded-xl border border-zinc-800 bg-zinc-950 text-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all shadow-none"
                    id="checkout-input-state"
                  >
                    <option value="" className="bg-zinc-950 text-white">Select State</option>
                    {indianStates.map((st) => (
                      <option key={st} value={st} className="bg-zinc-950 text-white">
                        {st}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">PIN Code *</label>
                  <input
                    type="text"
                    name="pinCode"
                    required
                    maxLength={6}
                    value={details.pinCode}
                    onChange={handleInputChange}
                    placeholder="6-digit PIN"
                    className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white placeholder-slate-650 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all shadow-none"
                    id="checkout-input-pincode"
                  />
                </div>
              </div>

              {/* Delivery Notes */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">Delivery Notes (Optional)</label>
                <textarea
                  name="notes"
                  rows={3}
                  value={details.notes || ''}
                  onChange={handleInputChange}
                  placeholder="e.g. Please deliver after 4:00 PM, or leave with neighbor if unavailable."
                  className="w-full text-xs py-3 px-3.5 rounded-xl border border-zinc-800 bg-zinc-950 text-white placeholder-slate-650 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all shadow-none resize-none"
                  id="checkout-input-notes"
                />
              </div>

              {/* Placing Order buttons */}
              <div className="pt-4 border-t border-zinc-800 space-y-4">
                <button
                  type="submit"
                  className="w-full py-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-none transition-all flex items-center justify-center gap-2 cursor-pointer"
                  id="checkout-place-order-btn"
                >
                  <MessageSquare className="w-4 h-4 fill-white/25" />
                  <span>Place Order & Open WhatsApp</span>
                </button>
                <p className="text-[10px] text-center text-slate-500">
                  By clicking Place Order, a formatted summary compiles instantly to launch WhatsApp chat with Shri Shyam Enterprises (+91 89497 01510) to finalize payment and dispatch coordinates.
                </p>
              </div>
            </form>
          </div>
        </div>

        {/* RIGHT COLUMN: ORDER SUMMARY SHEET (Col span 5) */}
        <div className="lg:col-span-5 bg-zinc-900/80 rounded-3xl border border-zinc-800 p-6 shadow-none space-y-6 lg:sticky lg:top-24">
          <div className="flex items-center gap-2 pb-3 border-b border-zinc-800">
            <ShoppingBag className="w-5 h-5 text-blue-400" />
            <h2 className="font-display font-bold text-white text-base">Order Accessories Summary</h2>
          </div>

          {cartItems.length === 0 ? (
            <div className="text-center py-8 space-y-3">
              <p className="text-xs text-slate-400">No items configured in your shopping cart.</p>
              <button
                onClick={() => onNavigateToPage('shop')}
                className="text-xs font-bold text-blue-400 hover:underline"
              >
                Go to Accessories Catalog
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Itemized list */}
              <div className="space-y-3 max-h-[40vh] overflow-y-auto pr-1">
                {cartItems.map((item) => (
                  <div key={item.id} className="flex gap-3 text-xs pb-3 border-b border-zinc-850 last:border-0 last:pb-0">
                    <div className="w-12 h-12 rounded-lg bg-zinc-950 overflow-hidden border border-zinc-850 flex-shrink-0">
                      <SafeImage productId={item.product.id} fallbackUrl={item.product.image} alt={item.product.name} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-semibold text-white truncate">{item.product.name}</h4>
                      {item.selectedOptions ? (
                        <div className="text-[9px] text-slate-500 truncate mt-0.5">
                          {item.selectedOptions.brand} {item.selectedOptions.model}
                          {item.selectedOptions.color && ` • ${item.selectedOptions.color}`}
                          {item.selectedOptions.glassType && ` • ${item.selectedOptions.glassType}`}
                        </div>
                      ) : (
                        <div className="text-[9px] text-slate-500 truncate mt-0.5">
                          {item.product.category}
                        </div>
                      )}
                      <div className="flex justify-between items-center mt-1">
                        <span className="text-slate-400">{item.quantity} x ₹{item.product.price}</span>
                        <span className="font-bold text-white">₹{item.product.price * item.quantity}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Subtotal calculation summary */}
              <div className="bg-zinc-950 rounded-2xl p-4 space-y-2 text-xs border border-zinc-850">
                <div className="flex justify-between text-slate-450">
                  <span>Cart Subtotal</span>
                  <span className="font-bold text-slate-200">₹{subtotal}</span>
                </div>
                <div className="flex justify-between text-slate-450">
                  <span>Tax GST (18%)</span>
                  <span className="font-bold text-slate-200">INCLUDED</span>
                </div>
                <div className="flex justify-between text-slate-450">
                  <span>Courier Shipping Charge</span>
                  <span className="text-green-400 font-bold uppercase font-mono text-[10px]">FREE DELIVERY</span>
                </div>
                <div className="flex justify-between items-end pt-2 border-t border-zinc-800 mt-2">
                  <span className="font-bold text-white text-sm">Amount Payable</span>
                  <span className="text-lg font-black text-blue-400">₹{subtotal}</span>
                </div>
              </div>

              {/* Delivery Assurance */}
              <div className="flex gap-2.5 p-3 rounded-xl bg-blue-950/20 border border-blue-900/30 text-[10px] text-slate-400">
                <Landmark className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  <strong>COD & Online UPI Options Available:</strong> Payment details will be finalized directly with support staff on WhatsApp. No payment gateway credentials are required on this website.
                </p>
              </div>
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
